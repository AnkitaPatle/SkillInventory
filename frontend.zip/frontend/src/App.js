import React from "react";
import "./App.css";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { Provider } from "react-redux";
import configureStore from "./configureStore";
import SkillsComponent from "./containers/skill/skill";
import LoginComponent from "./containers/login/login";
import Dashboard from "./containers/dashboard/dashboard";
import ManagerComponent from "./containers/manager/manager";
import DirectsComponent from "./containers/directs/directs";
import SkillClusterComponent from "./containers/skillcluster/skillcluster";
import MapskillsComponent from "./containers/skillcluster/mapskills/mapskills";
import EmployeeComponent from "./containers/employee/employee";
import LogoutComponent from "./containers/logout/logout";
import ProfileComponent from "./containers/profile/profile";
import AssignroleComponent from "./containers/admin/role/assignrole";
import AccountdeactivationComponent from "./containers/admin/account/accountdeactivation";
import ChangepasswordComponent from "./containers/admin/changepassword/changepassword";
import ApproveSkillComponent from "./containers/manager/approveskill";
import AddDirectSkillComponent from "./containers/manager/adddirectskill/adddirectskill";
import Askexpert from "./containers/askexpert/askexpert";
import PastqueryComponent from "./containers/askexpert/pastqueries";
import ReduxToastr from "react-redux-toastr";
import EditProfile from "./containers/profile/editProfile";
import MydirectsComponent from "./containers/manager/mydirects/mydirects";
import { getPathsFromCurrentRole } from "./Utils";
import EmployeeProfile from './containers/manager/mydirects/employeeProfile/employeeProfile';
import history from './history';
import AskexpertNew from "./containers/askexpert/askexpertNew";
import PastQueriesNew from './containers/askexpert/pastqueriesNew';

const location = window;
const store = configureStore();
function App() {;
  return (
    <Provider store={store}>
      <BrowserRouter>
        <div>
          <div className="vh-100">
            <Switch>
              <Route
                exact
                path="/"
                render={props => <LoginComponent key={location.pathname} />}
              />
              <Route
                exact
                path="/dashboard"
                render={props => <Dashboard key={location.pathname} />}
              />
              <Route
                exact
                path="/logout"
                render={props => <LogoutComponent key={location.pathname} />}
              />
              <Route
                exact
                path="/profile"
                render={props => <ProfileComponent key={location.pathname} />}
              />
              <Route
                exact
                path="/editProfile"
                render={props => <EditProfile key={location.pathname} />}
              />
              <Route
                exact
                path="/skill"
                render={props => <SkillsComponent key={location.pathname} />}
              />
              <Route
                exact
                path="/employee"
                render={props => <EmployeeComponent key={location.pathname} />}
              />
              <Route
                exact
                path="/cluster"
                render={props => (
                  <SkillClusterComponent key={location.pathname} />
                )}
              />
              <Route
                exact
                path="/mapskills"
                render={props => <MapskillsComponent key={location.pathname} />}
              />
              <Route
                exact
                path="/approveskill"
                render={props => (
                  <ApproveSkillComponent key={location.pathname} />
                )}
              />
              <Route
                exact
                path="/dirctskil"
                render={props => (
                  <AddDirectSkillComponent key={location.pathname} />
                )}
              />
              <Route
                exact
                path="/assignrole"
                render={props => (
                  <AssignroleComponent key={location.pathname} />
                )}
              />
              <Route
                exact
                path="/changepassword"
                render={props => (
                  <ChangepasswordComponent key={location.pathname} />
                )}
              />
              <Route
                exact
                path="/mydirects"
                render={props => <MydirectsComponent key={location.pathname} />}
              />
              <Route
                exact
                path="/empProfile"
                render={props => <EmployeeProfile key={location.pathname} />}
              />

               <Route
                exact
                path="/askexpert"
                render={props => <AskexpertNew key={location.pathname} />}
              />

              <Route
                exact
                path="/pastqueries"
                render={props => <PastQueriesNew key={location.pathname} />}
              /> 
            </Switch>
          </div>
        </div>
      </BrowserRouter>
      <ReduxToastr
        timeOut={5000}
        newestOnTop={true}
        position="bottom-left"
        transitionIn="bounceIn"
        transitionOut="bounceOut"
        progressBar
        closeOnToastrClick
        preventDuplicates
      />
    </Provider>
  );
}

export default App;
