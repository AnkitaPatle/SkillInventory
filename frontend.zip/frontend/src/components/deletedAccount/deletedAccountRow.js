import React, { Component } from "react";

class OperatorRow extends Component {
  constructor(props) {
    super(props);
  }

  onDeleteClick() {
    this.props.deletedSelectedAction(this.props.row);
  }

  render() {
    return (
      <tr>
        {Object.values(this.props.row).map((ele, i) => (
          <td key={i}>{ele}</td>
        ))}
        <td>
          <button
            className="btn btn-danger"
            onClick={this.onDeleteClick.bind(this)}
          >
            Delete Employee
          </button>
        </td>
      </tr>
    );
  }
}

export default OperatorRow;
