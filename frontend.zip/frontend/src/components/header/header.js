// Common header for application, includes Project title and User menu (@right corner)

import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";
import { API_URL } from "./../../config";
import "./header.css";
import { getAllUserInfo } from "./../../containers/profile/profileActions";
import logoimg from "./../../assets/images/logo1.png";
import { withRouter } from "react-router";
import { Redirect } from "react-router-dom";
import * as actions from "./../../containers/askexpert/askExpertAction";
import updtaeState from './../../containers/askexpert/askexpertNew';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      headerMessage: this.onheaderChange(props.history.location.pathname),
      empName: ""
    };
    props.history.listen((location, action) => {
      const headerMessage = this.onheaderChange(location.pathname);
      this.setState({ headerMessage });
    });
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(getAllUserInfo());
    let empName = localStorage.getItem('empName');
    this.setState({ empName });
  }

  hideHamburgerOnSameLinkClick = () => {
    document.getElementById("navbarSupportedContent").classList.remove("show"); 
    
  };

  onClick = e => {
    e.preventDefault();
    this.props.history.goBack();
  };

  onheaderChange = tabName => {
    let headerMessage = "";
    switch (tabName) {
      case "/dashboard":
        return (headerMessage = "Dashboard");
      case "/mydirects":
        return (headerMessage = "My Directs");
      case "/empProfile":
        return (  
          headerMessage = sessionStorage.getItem('empUsername').split('@')[0].split('.')[0] + " " + sessionStorage.getItem('empUsername').split('@')[0].split('.')[1]);
      case "/skill":
        return (headerMessage = "Add Skills");
      case "/cluster":
        return (headerMessage = "Skill Master");
      case "/employee":
        return (headerMessage = "Employee");
      case "/askexpert":
        return (headerMessage = "Ask An Expert");
      case "/pastqueries":
        return (headerMessage = "Search In Past Queries");
      default:
        return ""; 
    }
  };

  reloadData = () =>{
    const { dispatch } = this.props;
    dispatch(actions.getExpertList(""));
    document.getElementById("navbarSupportedContent").classList.remove("show"); 
    // updtaeState.updtaeState();
    this.props.resetSearchFilter && this.props.resetSearchFilter();
  }
  reloadPastData =()=>{
    this.props.resetSearchFilter && this.props.resetSearchFilter();
  }


  render() {
    const { users } = this.props;
    return (
      <div className="col-12">
        <nav className="navbar navbar-expand-lg navbar-dark navbar-custom">
          <button className="unstyled-button" onClick={this.onClick}>
            <i className="fa fa-angle-left d-lg-none" />
          </button>
          <span className="d-lg-none form-title-tab">
            {this.state.headerMessage}
          </span>

          <NavLink className="navbar-brand hide-logo" to="/dashboard">
            {/* HARBINGER <span>SKILL CLOUD</span> */}
            <img className="d-none d-sm-block" src={logoimg} />
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="fa fa-bars" />
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto navbar-nav-left flex-wrap">
              <NavLink className="nav-link d-lg-none" to="/profile">
                {this.props.users.profilePic ? (
                  <img
                    src={API_URL + "/" + this.props.users.profilePic}
                    className="avatar-image"
                  />
                ) : (
                  <img
                    src={require("../../assets/images/profile.jpg")}
                    className="avatar-image"
                  />
                )}
                <h3 className="avatar-title">
                  {users.firstname} {users.lastname}
                </h3>
              </NavLink>

              <NavLink
                className="nav-link nav-item"
                to="/dashboard"
                onClick={this.hideHamburgerOnSameLinkClick}
              >
                Dashboard
              </NavLink>

              {localStorage.role !== "Employee" ? (
                <NavLink
                  className="nav-link"
                  to="/mydirects"
                  onClick={this.hideHamburgerOnSameLinkClick}
                >
                  My Directs
                </NavLink>
              ) : (
                ""
              )}

              {localStorage.role == "Employee" ||
              localStorage.role == "CapDev" ? (
                <NavLink
                  className="nav-link"
                  to="/skill"
                  onClick={this.hideHamburgerOnSameLinkClick}
                >
                  Add Skills
                </NavLink>
              ) : (
                ""
              )}

              {localStorage.role == "CapDev" ? (
                <NavLink
                  className="nav-link"
                  to="/cluster"
                  onClick={this.hideHamburgerOnSameLinkClick}
                >
                  Skill Master
                </NavLink>
              ) : (
                ""
              )}

              {localStorage.role !== "Employee" ?(
                <NavLink
                  className="nav-link"
                  to="/employee"
                  onClick={this.hideHamburgerOnSameLinkClick}
                >
                  Employee
                </NavLink>
              ) : (
                ""
              )}

              {localStorage.role == "CapDev" || localStorage.role == "DM" ? (
                <NavLink
                  to="/empProfile"
                  onClick={this.hideHamburgerOnSameLinkClick}
                />
              ) : (
                ""
              )}

              <NavLink
                className="nav-link"
                to="/askexpert"
                onClick={this.reloadData}
              >
                Ask An Expert
              </NavLink>

              <NavLink
                className="nav-link"
                to="/pastqueries"
                onClick={this.reloadPastData}
              >
               Past Queries
              </NavLink>

              <NavLink className="nav-link d-lg-none" to="/profile">
                Profile
              </NavLink>
              <NavLink className="nav-link d-lg-none" to="/logout">
                Logout
              </NavLink>
            </ul>
            <ul className="navbar-nav my-2 my-lg-0 navbar-nav-right d-none d-lg-block">
              <li className="nav-item dropdown">
                <a
                  className="nav-link"
                  href="#"
                  id="dropdownMenuLink"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                <span>
                   {this.props.users.profilePic ? (
                  <img
                    src={API_URL + "/" + this.props.users.profilePic}
                    className="img-profile rounded-circle mr-2" width="45px" height="45px"
                  />
                ) : (
                  <img
                    src={require("../../assets/images/profile.jpg")}
                    className="img-profile rounded-circle mr-2" width="45px" height="45px"
                  />
                )}
                </span>                 
                {/* <img src={API_URL + "/" + this.props.users.profilePic} className="img-profile rounded-circle mr-2" width="45px" height="45px"/> */}
                  <span className="mr-2 d-none d-lg-inline">
                    Hello {` ` + localStorage.getItem("userName")}
                  </span>
                  
                  <span className="fa fa-angle-down" />
                </a>
                <div
                  className="dropdown-menu dropdown-menu-right"
                  aria-labelledby="dropdownMenuLink"
                >
                  <NavLink className="dropdown-item" to="/profile">
                    Profile
                  </NavLink>
                  <NavLink className="dropdown-item" to="/logout">
                    Logout
                  </NavLink>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    );
  }
}

const mapStateToProps = state => {
  let users = {};
  if (state.profileReducer.users !== undefined) {
    users = state.profileReducer;
    return users;
  } else {
    return { users };
  }
};

export default connect(mapStateToProps)(withRouter(Header));
