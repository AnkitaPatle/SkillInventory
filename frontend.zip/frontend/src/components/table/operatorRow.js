import React, { Component } from "react";
import "./opratorRow.css";
class OperatorRow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      assignbutton: true,
      removebutton: false
    };
  }

  onManagerClick() {
    this.props.managerSelectedAction(this.props.row); // it will assign role of DM to selected employee
    this.setState({
      assignbutton: !this.state.assignbutton, // button toggling
      removebutton: !this.state.removebutton
    });
  }

  onCapDevClick() {
    this.props.capDevSelectedAction(this.props.row);
  }

  removeRole() {
    this.props.capDevSelectedAction(this.props.row);
  }
  render() {
    return (
      <tr>
        {Object.values(this.props.row).map((ele, i) => <td key={i}>{ele}</td>)}
        <td>
          {this.state.assignbutton && (
            <button
              className="btn btn-info assignrole"
              onClick={this.onManagerClick.bind(this)}
            >
              Make DM
            </button>
          )}
          {this.state.removebutton && (
            <button
              className="btn btn-info removerole"
              onClick={this.onManagerClick.bind(this)}
            >
              Remove Manager
            </button>
          )}
          <button
            className="btn btn-danger removerole"
            onClick={this.onManagerClick.bind(this)}
          >
            Remove Manager
          </button>
        </td>
        <td>
          <button
            className="btn btn-success "
            onClick={this.onCapDevClick.bind(this)}
          >
            CapDev
          </button>
        </td>
      </tr>
    );
  }
}

export default OperatorRow;
