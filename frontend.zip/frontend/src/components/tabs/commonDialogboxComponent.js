import React, { Component } from "react";
import Modal from "react-modal";

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)"
  },
  skillname: {
    fontSize: "25px",
    textTransform: "Capitalize"
  },
  divider: {
    borderTop: "1px dashed #989898",
    paddingTop: "30px",
    marginTop: "30px"
  },
  selectyear: {
    border: "none",
    borderBottom: "1px solid #989898",
    borderRadius: "0px"
  },
  radio: {
    marginLeft: "10px"
  },
  skillstatus: {
    padding: "0px"
  },
  title: {
    fontSize: "20px",
    textTransform: "Capitalize",
    marginBottom: "30px"
  },
  overlay: {
    background: "#6e6e6e"
  },
  buttons: {
    margin: "20px!important"
  }
};

class CommonDialogboxComponent extends Component {
  constructor(props) {
    super(props);
    this.state={
        modalIsOpen: this.props.modelOpen ? true : false,
    }
  }
  cancelModal(){
   
  }

  render() {
    return (
      <div>
        <Modal
          isOpen={this.state.modalIsOpen}
          onAfterOpen={this.afterOpenModal}
          onRequestClose={this.closeModal}
          style={customStyles}
          contentLabel="Example Modal"
        >
          <h2 ref={subtitle => (this.subtitle = subtitle)}>
            Skill Update Form
          </h2>
          <div />
          <Modal
            isOpen={this.state.modalIsOpen}
            onAfterOpen={this.afterOpenModal}
            onRequestClose={this.closeModal}
            style={customStyles}
            styles={{ overlay: { background: "#FFFF00", opacity: "0.5" } }}
            contentLabel="Example Modal"
          >
            <div />
            <div className="row">
              <div className="col-md-12">
                <div>
                  <div className="form-group">
                        {this.props.message} 
                  </div>
                </div>  
              </div>
              <div className="col-md-12">
                <center>
                  <button
                    className="btn btn-danger"
                    onClick={this.cancelModal}
                    style={{
                      borderRadius: "30px",
                      margin: "20px!important",
                      padding: "7px 20px"
                    }}
                  >
                    Cancel
                  </button>

                   <button
                    className="btn btn-primary"
                    onClick={this.addSkill}
                    style={{
                      borderRadius: "30px",
                      marginTop: "20px !important",
                      padding: "7px 20px"
                    }}
                  >
                    Confirm
                  </button>
                </center>
              </div>
            </div>
          </Modal>
          <form>
            <input />
            <button onClick={this.cancelModal}>close</button>
          </form>
        </Modal>
      </div>
    );
  }
}

export default CommonDialogboxComponent;
