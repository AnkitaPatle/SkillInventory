import React, { Component } from "react";
import { Button } from "react-md";
import "./tabs.css";
import SkillTableRow from "./skilltablerow";

class PendingComponent extends Component {
  constructor(props) {
    super(props);
  }

  onDeleteClick = e => {
    return this.props.getdeletedrow(e);
  };

  openModel = e => {
    return this.props.getselectedrow(e);
  };

  render() {
    return this.props.pendingList.length !== 0 ?  
    this.props.pendingList.map((ele, i) => (
      <SkillTableRow
        pendingData={ele}
        key={i}
        ondeleteclick={this.onDeleteClick}
        onrowclickpending={this.openModel}
      />
    )) 
    : null
  }
}

export default PendingComponent;
