import React, { Component, useState, setShow } from "react";
import "./tabs.css";
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import { DeleteSkillsModal } from '../../containers/delete-skills-modal/delete-skills-modal.component';
import * as actions from "./../../containers/dashboardskill/dashboardSkillActions";
import * as dashboardAction from "./../../containers/dashboard/dashboardAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { toastr } from 'react-redux-toastr';
import StarRating from "./../../components/starRating/starRating";
import Moment from 'react-moment';

class SkillTableRow extends Component {
  closeDeleteSkillsModal = () => {
    return this.setState({ show: false, setShow: false })
  };

  deleteSkillPending = (props) => {
    const pendingSkillname = this.props.pendingData.skillname && this.props.pendingData.skillname.charAt(0).toUpperCase() + this.props.pendingData.skillname.slice(1);
    const { dispatch } = this.props;
    Promise.resolve(dispatch(actions.deleteSkill(this.props.pendingData))).then(res => {
      toastr.success('Success', '"'+ pendingSkillname +'"' + " skill deleted successfully.", { showCloseButton: false,
        timeOut: 3000 })
      return dispatch(dashboardAction.getAllSkillsByLevel());
    }
    );
    return this.setState({ show: false, setShow: false })
  };

  deleteSkillApproved = (props) => {
    const approvedSkillname = this.props.approvedData.skillname && this.props.approvedData.skillname.charAt(0).toUpperCase() + this.props.approvedData.skillname.slice(1);
    const { dispatch } = this.props;
    Promise.resolve(dispatch(actions.deleteSkill(this.props.approvedData))).then(res => {
      toastr.success('Success', '"'+ approvedSkillname +'"' + " skill deleted successfully.", { showCloseButton: false,
        timeOut: 3000 })
      return dispatch(dashboardAction.getAllSkillsByLevel());
    }
    );
    return this.setState({ show: false, setShow: false })
  }

  constructor(props) {
    super(props);
    this.state = {
      show: false,
      setShow: false
    };

  }

  openModel = e => {
    return this.props.onrowclick(this.props.approvedData);
  };

  onrowclickpending = e => {
    return this.props.onrowclickpending(this.props.pendingData);
  };

  onApprovedDeleteClick = e => {
    this.props.ondeleteclick(this.props.approvedData);
    return this.setState({ show: true, setShow: true });
  };

  onPendingDeleteClick = e => {
    this.props.ondeleteclick(this.props.pendingData);
    return this.setState({ show: true, setShow: true });
  };
  onChangeExpertiseLevel(rating) {
    this.setState({ expertiseLevel: rating });
    this.setState({ message: "" });
  }
  render() {
    return this.props.pendingData != undefined ? (
      <tr className="pending-notation">
        <td className="dashboard-skill-table-skillset">
          <div className="table-skillset hideMob">{this.props.pendingData["skillname"]}</div>
          <div className="showMob flex-column">
            <div className="table-skillset"><b>{this.props.pendingData["skillname"]}</b></div>
            <div><b>Experience Level: </b>
               <StarRating
                handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                rating={this.props.pendingData["level"]} disableClick={true} >
              </StarRating>
            </div>
            <div><b>Experience: </b>{this.props.pendingData["experience"]}</div>
            <div><b>Practicing: </b>{this.props.pendingData["currentStatus"] === "Practising" ? "Yes" : "No"}{" "}{" "}</div>
            <div><b>Last Used/Since Using: </b>{this.props.pendingData["year"]}</div>
          </div>
        </td>

        <td className="hideMob">
          <StarRating
            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
            rating={this.props.pendingData["level"]} disableClick={true} >
          </StarRating>
        </td>

        <td className="hideMob">
           <Moment format="MM/DD/YYYY">
              {this.props.pendingData["createdDate"]}
            </Moment>         
        </td>

        <td className="hideMob">
          {this.props.pendingData["experience"]}
        </td>

        <td className="pullRightMob dashboard-skill-table-lastused">
          <div className="table-lastused hideMob">
            {this.props.pendingData["currentStatus"] === "Practising" ? "Yes" : "No"}{" "}{" "}
          </div>   
          <div className="showMob date-text-bold">
           <div className="showMobDate">
              <Moment format="MM/DD/YYYY">
              {this.props.pendingData["createdDate"]}
            </Moment>
            </div>
          </div>   

          <div className="showMob">
            <div>
              <i
                className="icon icon-edit action-icon"
                aria-hidden="true"
                onClick={this.onrowclickpending}
              />
            </div>
            <div>
              <i className="icon icon-delete action-icon mr-0" onClick={this.onPendingDeleteClick} />
            </div>
          </div>  
        </td>

        <td className="hideMob dashboard-skill-table-status">
          <div className="table-lastused">{this.props.pendingData["year"]}</div>
        </td>

        <td className="hideMob dashboard-skill-table-status">
          <div className="table-lastused">{this.props.pendingData["comment"]}</div>
        </td>

        <td className="hideMob dashboard-skill-table-action">         
          <div className="d-flex">
            <div>
              <i
                className="icon icon-edit action-icon"
                aria-hidden="true"
                onClick={this.onrowclickpending}
              />
            </div>
            <div>
              <i className="icon icon-delete action-icon mr-0" onClick={this.onPendingDeleteClick} />
            </div>
          </div>
        </td>
        <DeleteSkillsModal closeDeleteSkillsModal={this.closeDeleteSkillsModal} show={this.state.show} handleDelete={this.deleteSkillPending} skillname={this.props.pendingData.skillname} />
      </tr>
    ) : (
        <tr>
          <td className="dashboard-skill-table-skillset">
            <div className="table-skillset hideMob">
              {this.props.approvedData["skillname"]}
            </div>

            <div className="showMob flex-column">
              <div className="table-skillset"><b>{this.props.approvedData["skillname"]}</b></div>
              <div><b>Experience Level: </b>
                <StarRating
                  handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                  rating={this.props.approvedData["level"]} disableClick={true} >
                </StarRating>
              </div>
              <div><b>Experience: </b>{this.props.approvedData["experience"]}</div>
              <div><b>Practicing: </b>{this.props.approvedData["currentStatus"] === "Practising" ? "Yes" : "No"}{" "}{" "}
                <div><b>Last Used/Since Using: </b>{this.props.approvedData["year"]}</div>
              </div>
            </div>
          </td>

          <td className="hideMob">
            <StarRating
              handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
              rating={this.props.approvedData["level"]} disableClick={true} >
            </StarRating>
          </td>

          <td className="hideMob">
            <Moment format="MM/DD/YYYY">
              {this.props.approvedData["createdDate"]}
            </Moment>
          </td>
          
          <td className="hideMob">
            {this.props.approvedData["experience"]}
          </td>

          <td className="pullRightMob dashboard-skill-table-lastused">
            <div className="table-lastused hideMob">
              {this.props.approvedData["currentStatus"] === "Practising" ? "Yes" : "No"}{" "}{" "}
            </div>

            <div className="showMob">
              <div className="showMobDate date-text-bold">
                <Moment format="MM/DD/YYYY">
                {this.props.approvedData["createdDate"]}
              </Moment>
              </div>
            </div>

            <div className="showMob">               
              <div>
                <i
                  className="icon icon-edit action-icon"
                  aria-hidden="true"
                  onClick={this.openModel}
                />
              </div>
              <div>
                <i className="icon icon-delete action-icon mr-0" onClick={this.onApprovedDeleteClick} />
              </div>
            </div>
          </td>

          <td className="hideMob dashboard-skill-table-status">
            <div>
              {this.props.approvedData["year"]}
            </div>
          </td>

          <td className="hideMob dashboard-skill-table-status">
            <div className="table-lastused">{this.props.approvedData["comment"]}</div>
          </td>

          <td className="hideMob dashboard-skill-table-action">
            <div className="d-flex">
              <div>
                <i
                  className="icon icon-edit action-icon"
                  aria-hidden="true"
                  onClick={this.openModel}
                />
              </div>
              <div>
                <i className="icon icon-delete action-icon mr-0" onClick={this.onApprovedDeleteClick} />
              </div>
            </div>
          </td>
          <DeleteSkillsModal closeDeleteSkillsModal={this.closeDeleteSkillsModal} show={this.state.show} handleDelete={this.deleteSkillApproved} skillname={this.props.approvedData.skillname} />
        </tr>
      );
  }
}

SkillTableRow.propTypes = {
  deleteSkill: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    editinfo: state.dashboardskillReducer.editinfo || "",
    deleteinfo: state.dashboardskillReducer.deleteinfo || ""
  };
};
export default connect(mapStateToProps)(SkillTableRow);

