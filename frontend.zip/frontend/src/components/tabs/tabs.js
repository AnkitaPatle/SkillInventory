// This component contains tabs which are displayed on dashboard
import React from "react";
import PropTypes from "prop-types";
import { NavLink } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import "./tabs.css";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import DashboardSkills from "../../containers/dashboardskill/dashboardskills";
import SkillHeader from "./skillHeader";
import dataImage from "../../assets/images/dataImage.png";

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 0 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired
};

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
    margin: "5% 0",
    background: "#eeeeee"
  },
  indicator: {
    backgroundColor: "#0693e8"
  },
  flexContainer: {
    borderBottom: "1px solid #f4f4f4"
  },
  tabRoot: { borderColor: "#fff" }
});

class SimpleTabs extends React.Component {
  state = {
    value: 0
  };
  handleChange = (event, value) => {
    this.setState({ value });
  };
  render() {
    const { classes } = this.props;
    const { value } = this.state;
    return (
      <div className={classes.root}>
        <AppBar position="static">
          <div className="row tabs">
            <div className="col-md-9 tabmenu">
              <Tabs
                value={value}
                onChange={this.handleChange}
                classes={{
                  indicator: classes.indicator,
                  flexContainer: classes.flexContainer
                }}
              >
                <Tab id="expert" label="Expert" className="expert"
                  classes={{ root: classes.tabRoot }}
                />
                <Tab id="practitioner" label="Practitioner" className="practitioner" />
                <Tab id="novice" label="Novice" className="novice" />
              </Tabs>
            </div>
            <div className="col-md-3 newskillbutton">
              <button className="addnewskill custom-btn">
                <NavLink className="hideMob" to="/skill">
                  Add Skills
                </NavLink>
                <NavLink className="showMob fa fa-plus" to="/skill">

                </NavLink>
              </button>
            </div>
          </div>
        </AppBar>
        {value === 0 && (
          <TabContainer>
            <table className="table dashboard-skill-table">
              <tbody>
                <tr>
                  <td colSpan="4" className="no-border">
                    <i className="fa fa-square" aria-hidden="true" /> Skills sent
                  for Manager Approval!
                  </td>
                </tr>
                <SkillHeader />
                {this.props.childData && this.props.childData.length > 0 ? (
                  <DashboardSkills expertList={this.props.childData} />
                ) : 
                 <tr><td className="tableStyle">No data available!</td> </tr>
               
                }
              </tbody>
            </table>
          </TabContainer>
        )}
        {value === 1 && (
          <TabContainer>
            <table className="table dashboard-skill-table">
              <tr>
                <td colSpan="4" className="no-border">
                  <i class="fa fa-square" aria-hidden="true" /> Skills sent
                  for Manager Approval!
                </td>
              </tr>
              <SkillHeader />
              {this.props.practitionerData && this.props.practitionerData.length > 0 ? (
                <DashboardSkills expertList={this.props.practitionerData} />
              ) : <tr><td className="tableStyle"> No data available!</td> </tr>}
            </table>
          </TabContainer>
        )}

        {value === 2 && (
          <TabContainer>
            <table className="table dashboard-skill-table">
              <tr>
                <td colSpan="4" className="no-border">
                  <i className="fa fa-square" aria-hidden="true" /> Skills sent
                  for Manager Approval!
                </td>
              </tr>
              <SkillHeader />

              {this.props.noViceData && this.props.noViceData.length > 0 ? (
                <DashboardSkills expertList={this.props.noViceData} />
              ) : <tr><td className="tableStyle"> No data available!</td> </tr>}
            </table>
          </TabContainer>
        )}
      </div>
    );
  }
}

SimpleTabs.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(SimpleTabs);
