//export const API_URL = " http://10.0.10.133:3300";
export const API_URL = " https://10.0.10.196:3200";
// export const API_URL = " http://localhost:3200";

export const Headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
}