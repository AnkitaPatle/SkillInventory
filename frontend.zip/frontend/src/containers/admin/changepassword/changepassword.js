// his component is developed to allow admin to change password. Password  strength meter 	is implemented to check the strength of a password entered by admin user.
// “passwordStrengthMeter” package is used to check strength of password. This component has functionality of  - notification through mail to change password after
//particular days, auto password change after 80 days, password before 25 days and daily 	before 5days. (All this functionality is managed through back-end of this  project )

import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import PasswordStrengthMeter from "./passwordStrengthMeter";
import Header from "../../../components/header/header";
import Routing from "../../../routing";
import * as actions from "./changePasswordActions";
import "../../../assets/css/common.css";
import "./changepassword.css";
import { Redirect } from "react-router-dom";

class ChangepasswordComponent extends Component {
  state = {
    oldpassword: "",
    newpassword: "",
    confimrpassword: "",
    message: "",
    password: ""
  };

  changeCallback = state =>
    this.setState({ passLength: state.newpassword.length });

  onChangeTextBoxValue(e) {
    this.setState({ [e.target.name]: e.target.value });
    this.setState({ message: "" });
  }

  onBlur(e) {
    if (this.props.loginInfo.password !== undefined) {
      if (this.state.oldpassword !== this.props.loginInfo.password) {
        this.setState({ message: "Current password doesn't match" });
        this.oldpasswordInput.focus();
      }

      if (this.state.oldpassword === this.state.newpassword) {
        this.setState({
          message: "Current password and New password are same. Please change."
        });
        this.newpasswordInput.focus();
      }

      if (this.state.newpassword != this.state.confimrpassword) {
        this.setState({
          message: "New password and confirm password doesn't match"
        });
        this.confirmpasswordInput.focus();
      }
    }
  }
  onClickClear(e) {
    this.setState({ oldpassword: "" });
    this.setState({ newpassword: "" });
    this.setState({ confimrpassword: "" });
    this.setState({ message: "" });
  }

  OnClickChangePassword() {
    if (this.props.loginInfo.password != undefined) {
      if (
        this.state.oldpassword != "" &&
        this.state.newpassword != "" &&
        this.state.confimrpassword != ""
      ) {
        if (this.state.oldpassword === this.props.loginInfo.password) {
          if (this.state.oldpassword === this.state.newpassword) {
            this.setState({
              message:
                "Current password and New password are same. Please change."
            });
            this.focus();
          } else if (this.state.newpassword === this.state.confimrpassword) {
            const admin = {
              oldPassword: this.state.oldpassword,
              newPassword: this.state.newpassword
            };

            const { dispatch } = this.props;
            dispatch(actions.changePassword(admin));

            this.onClickClear();
          } else {
            this.onClickClear();
            this.setState({
              message: "New password and confirm password doesn't match"
            });
          }
        } else {
          this.setState({ message: "Current password doesn't match" });
        }
      } else {
        this.onClickClear();
        this.setState({ message: "please enter all value" });
      }
    } else {
      alert("Session is log off!!! Please Login again!!!");
      this.onClickClear();
    }
  }

  render() {
    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }
    const { newpassword } = this.state;

    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-2">
              <Routing />
            </div>
            <div className="col-md-4">
              <div className="sectiontitle">
                <h2> Change Password </h2>
              </div>

              {this.state.message ? (
                <label className="colorcombo">{this.state.message} </label>
              ) : (
                ""
              )}
              <div className="colorcombo">
                {this.props.roleStatus != "" ? this.props.roleStatus : ""}
              </div>
              <div className="form-group">
                <label htmlFor="oldpassword">Current Password</label>
                <input
                  type="password"
                  name="oldpassword"
                  id="oldpassword"
                  value={this.state.oldpassword}
                  onChange={this.onChangeTextBoxValue.bind(this)}
                  onBlur={this.onBlur.bind(this)}
                  ref={input => {
                    this.oldpasswordInput = input;
                  }}
                  className="form-control formtextbox"
                />
              </div>
              <div className="form-group">
                <label htmlFor="newpassword">New Password</label>
                <div className="meter">
                  <input
                    name="newpassword"
                    id="newpassword"
                    autoComplete="off"
                    type="password"
                    value={this.state.newpassword}
                    onChange={e =>
                      this.setState({ newpassword: e.target.value })}
                    ref={input => {
                      this.newpasswordInput = input;
                    }}
                    onBlur={this.onBlur.bind(this)}
                    className="form-control formtextbox"
                  />
                  <PasswordStrengthMeter newpassword={newpassword} />
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="confirmpassword">Confirm Password</label>
                <input
                  type="password"
                  name="confimrpassword"
                  id="confimrpassword"
                  value={this.state.confimrpassword}
                  onChange={this.onChangeTextBoxValue.bind(this)}
                  onBlur={this.onBlur.bind(this)}
                  ref={input => {
                    this.confirmpasswordInput = input;
                  }}
                  className="form-control formtextbox"
                />
              </div>
              <div className="form-group">
                <button
                  className="btn btn-success"
                  onClick={this.OnClickChangePassword.bind(this)}
                >
                  {" "}
                  Change{" "}
                </button>
                <button
                  className="btn btn-danger margin-20"
                  type="reset"
                  onClick={this.onClickClear.bind(this)}
                >
                  Clear
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

ChangepasswordComponent.propTypes = {
  EmployeeLogin: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    loginInfo: state.loginReducer.loginInfo || {},
    roleStatus: state.changePasswordReducer.passwordStatus || ""
  };
};

export default connect(mapStateToProps)(ChangepasswordComponent);
