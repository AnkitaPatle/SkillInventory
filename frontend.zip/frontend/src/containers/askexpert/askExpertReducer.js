import * as actionTypes from "./askExpertActionType";
const askExpertReducer = (state = {}, action) => {
  switch (action.type)
  {
    case actionTypes.FETCH_EMPLOYE_BY_SKILL:
      return Object.assign({}, state, {
        employeeSkillsBySkill: action.payload
      });
    case actionTypes.SEND_QUERY_TO_EXPRT:
      return Object.assign({}, state, {
        querysendStatus: action.payload
      });
    case actionTypes.GET_SEND_QUERY:
      return Object.assign({}, state, {
        querysenddata: action.payload
      });
    case actionTypes.CLEAR_SEARCH:
      return Object.assign({}, state, {
         querysenddata: action.payload,
      });
      case actionTypes.FETCH_EXPERT_BY_SKILL:
        return Object.assign({}, state, {
          expertBySkill: action.payload
        });
        case actionTypes.CLEAR_ASK_EXPERT_SEARCH:
      return Object.assign({}, state, {
        expertBySkill: action.payload
      });
    default:
      return state;
  }
};
export default askExpertReducer;
