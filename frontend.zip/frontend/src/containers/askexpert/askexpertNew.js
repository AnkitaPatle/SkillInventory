import React, { Component, useState } from "react";
import { toastr } from "react-redux-toastr";
import * as actions from "./askExpertAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import askExpertReducer from "./askExpertReducer";
import AskExprtScreenNew from "./askexpertscreenNew";
import StarRating from "../../components/starRating/starRating";
import Header from "../../components/header/header";
import Autosuggest from "react-autosuggest";
import * as skillsactions from "../skill/skillActions";
import { Tooltip } from 'react-bootstrap';
import { API_URL } from '../../config';
import { Redirect } from "react-router-dom";
// import medals from './../../assets/images/medal.png';
import medals from './../../assets/images/award.png';

let suggestedskills = [];
const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : suggestedskills.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;

class AskexpertNew extends React.PureComponent {
  state = {
    srchval: "",
    dtaarr: [
      { srno: "", empname: "", delmanager: "", role: "", exprtlevel: "" }
    ],
    isModelOpen: false,
    value: "",
    suggestions: [],
    skillName: "",
    modalTitle: ""
  };

  resetSearchFilter = () =>{
    this.setState({value:""});
  }


  componentDidMount = (e) => {
    
    const { dispatch } = this.props;
    dispatch(actions.clearExpertSearchQuery())
    dispatch(actions.getExpertList(""))
  }

  getsrchval = e => {
    this.setState({
      srchval: e.target.value
    });
  };
  getEMpListBySkill = () => {
    const { dispatch } = this.props;
    if (this.state.value !== "" && this.state.value.trim()) {
      dispatch(actions.getExpertList(this.state.srchval.toLocaleLowerCase())).then((res) => {
        if (this.props.expertBySkill.length == 0) {
          toastr.warning("Warning!", "No Experts available for this Skill!", {
            showCloseButton: false,
            timeOut: 3000
          });
        }
        this.setState({value:""})
      });
    } else {
      const { dispatch } = this.props;
      dispatch(actions.getExpertList(""))
      toastr.warning("Warning!", "To Search an Expert, Please enter Skills and Press Search Button!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  };

  openModel = (data, title) => {
    this.setState({
      dtaarr: data
    });
    this.setState({
      isModelOpen: true,
      modalTitle: title
    });
  };
  close = () => {
    this.setState({
      isModelOpen: false
    });
  };

  sendQueryToexpert = query => {
    const { dispatch } = this.props;
    dispatch(actions.sendQueryToExpert(query)).then(() => {
      toastr.success("Success", "Query sent to expert successfully.", {
        showCloseButton: false,
        timeOut: 3000
      });
    });
    this.setState({
      isModelOpen: false
    });
  };

  ratingCheck = e => { };

  onChangeSkillName(e) {
    this.setState({ skillName: e.target.value });
    this.setState({ message: "" });
    const { dispatch } = this.props;
    const skillname = { skillname: e.target.value };
    dispatch(skillsactions.ChangeStatus());
  }

  onSuggestionsFetchRequested = ({ value }) => {
    if(value !==  "")
    {
      const { dispatch } = this.props;
      dispatch(actions.getExpertList(""));
    }
    if (value.length <= 60) {
      this.setState({
        srchval: value,
        suggestions: getSuggestions(value)
      });
    } else {
      this.setState({
        srchval: value.slice(0, 60),
        suggestions: getSuggestions(value.slice(0, 60)),
        value: value.slice(0, 60)
      });
    }
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };
  onChange = (event, { newValue }) => {   
    this.setState({ srchval: newValue });
    this.setState({ value: newValue });
    const { dispatch } = this.props;
    const skillname = { skillname: event.target.value };
    dispatch(skillsactions.getAllSkillsFromCluster(skillname));
  };

  enterClick = () => {
  }

  onEnterKeyPress = e => {
    if (e.key === "Enter") {
      this.getEMpListBySkill();
    }
  };

  render() {

    // console.log(this.props.expertBySkill , "this.props.expertBySkill")
    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }
    suggestedskills = this.props.allskills;
    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: "Enter Skills and Press Search Button!",
      value,
      onChange: this.onChange,
      onKeyPress: this.onEnterKeyPress
    };
    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header resetSearchFilter={this.resetSearchFilter}/>
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <h1 className="dashboard-page-title">Ask An Expert</h1>
              <div className="row">
                <div className="add-skill-autosuggest-container input-group col-xl-3 col-lg-4 col-md-6 col-sm-6">
                  <Autosuggest
                    suggestions={suggestions}
                    onSuggestionsFetchRequested={
                      this.onSuggestionsFetchRequested
                    }
                    onSuggestionsClearRequested={
                      this.onSuggestionsClearRequested
                    }
                    getSuggestionValue={getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                    inputProps={inputProps}
                    name="skillname"
                    value={this.state.value}
                    className="col-md-4 form-control"
                    onSuggestionSelected={this.enterClick}
                  />
                  <button
                    className="btn btn-add"
                    onClick={e => this.getEMpListBySkill(e)}
                  >
                    <i className="fa fa-search btn-add-icon" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
              <div className="dashboard-para-search-text">
                Experts: {this.props.expertBySkill.length}
              </div>
              <div>
                <table className="table hideMob ask-expert-table">
                  {this.props.expertBySkill.length > 0 ? (
                    <thead>
                      <th width="15%">EMPLOYEE NAME</th>
                      <th width="15%">SKILLSET</th>
                      <th width="15%">DELIVERY MANAGER</th>
                      <th width="15%">ROLE</th>
                      <th width="15%">RESOLVE COUNT</th>
                      <th width="15%">EXPERTISE LEVEL</th>
                      <th width="5%">ACTION</th>
                    </thead>
                  ) : null}
                  <tbody>
                    {this.props.expertBySkill.length > 0 ? this.props.expertBySkill.map((items, key) => {
                      let email = '';
                      { items.managers && items.managers !== "-" ? items.managers && items.managers !== 0 ?
                      email = (items.managers.toUpperCase()) :
                      email = '-. @mail.com' : email = '-'}
                     
                      return (
                        <tr>
                          <td>
                            <div className="ask-expert-table-col-name">
                              {items.profilepic !== "" ? <img src={API_URL + "/" + items.profilepic} /> : <img src={require("./../../assets/images/profile.jpg")} />}
                              {items.firstname} {items.lastname}
                            </div>
                          </td>
                          <td>{items.skillname}</td>
                          <td>{email !== "-" ? email.split('.')[0] + ' ' + email.split('.')[1].split('@')[0] : "-"}</td>
                          <td>{items.designation}</td>
                          {/* {items.ResolveCount === 1 ? <td><img src={medals} className='fas fa-medal' style={{width:"10%",height:"7%"}} /> {items.ResolveCount}</td>
                          : items.ResolveCount === 2 ? <td><img src={medals} className='fas fa-medal' style={{width:"10%",height:"7%"}} />
                          <img src={medals} className='fas fa-medal' style={{width:"10%",height:"7%"}} />
                           {items.ResolveCount}</td> :items.ResolveCount === 2 ? <td><img src={medals} className='fas fa-medal' style={{width:"10%",height:"7%"}} />
                           <img src={medals} className='fas fa-medal' style={{width:"10%",height:"7%"}} />
                          <img src={medals} className='fas fa-medal' style={{width:"10%",height:"7%"}} />
                           {items.ResolveCount}</td> : ""} */}
                          <td>{items.ResolveCount > 0 ? <img src={medals} className='fas fa-medal' style={{padding:"3%"}} />:<span style={{padding:"7%"}}></span>}
                          {items.ResolveCount}</td>
                          <td>
                            <StarRating
                              name={items.firstname + items.lastname}
                              handleRatingChangeProp={this.ratingCheck.bind(
                                this
                              )}
                              rating={items.level === "FPractitioner" ?items.level.slice(1):items.level}
                              disableClick={true}
                            ></StarRating>
                          </td>
                          <td>
                            <span
                              className="ask-expert-ask-action"
                              onClick={e => {
                                this.openModel(items, "Ask An Expert");
                              }}
                            >
                              Ask
                                </span>
                          </td>
                        </tr>
                      );
                    })
                      : null}
                  </tbody>
                </table>
                {
                  this.props.expertBySkill.length > 0 ? (
                  this.props.expertBySkill.map((items, key) => {
                    let email = '';
                      { items.managers && items.managers !== "-" ? items.managers && items.managers !== 0 ?
                      email = (items.managers.toUpperCase()) :
                      email = '-. @mail.com' : email = '-'}
                      const skillname = items.skillname && items.skillname.charAt(0).toUpperCase() + items.skillname.slice(1);

                    return (
                    <div className="showMob past-queries-list-mob">
                      <div className="past-queries-list-mob-item">
                      <div className="d-flex justify-content-between align-items-center py-3">
                      <div className="ask-expert-table-mob-col-name">
                        {items.profilepic !== "" ? <img src={API_URL + "/" + items.profilepic} /> : <img src={require("./../../assets/images/profile.jpg")} />}
                        <div>
                          <p className="mb-0 past-queries-text-bold">{items.firstname} {items.lastname}</p>
                          <p className="mb-0 past-queries-text">{items.designation}</p>
                        </div>
                      </div>
                      </div>
                        <div><b>Skillset: </b>{skillname}</div>
                        <div><b>DM: </b>{email !== "-" ? email.split('.')[0] + ' ' + email.split('.')[1].split('@')[0] : "-"}</div>
                        <div><b>Expertise Level: </b>
                          <StarRating
                              name={items.firstname + items.lastname}
                              handleRatingChangeProp={this.ratingCheck.bind(
                                this
                              )}
                              rating={items.level === "FPractitioner" ?items.level.slice(1):items.level}
                              disableClick={true}

                          ></StarRating>
                        </div>
                        <div><b>Resolved Count: </b>{items.ResolveCount > 0 ? <img src={medals} className='fas fa-medal' style={{padding:"3%"}} />:<span></span>}
                          {items.ResolveCount}</div>

                      {/* <div className="ask-expert-table-mob-col-rating">
                        <StarRating
                              name={items.firstname + items.lastname}
                              handleRatingChangeProp={this.ratingCheck.bind(
                                this
                              )}
                              rating={items.level === "FPractitioner" ?items.level.slice(1):items.level}
                              disableClick={true}

                            ></StarRating>
                      </div> */}
                       <div>
                        <span
                          className="ask-expert-ask-action"
                          onClick={e => {
                            this.openModel(items, "Ask an Expert");
                          }}
                        >
                          Ask
                        </span>
                      </div> 
                      </div>
                    </div>
                  );
                  })
                )                 
                : (
                    <div className="d-flex flex-column align-items-center justify-content-center">
                      <img
                        src={require("../../assets/images/ask-an-expert.jpg")}
                        className="img-fluid"
                      />
                      <h2>Need Help? Ask an Expert</h2>
                    </div>
                  )}
              </div>
              {this.state.isModelOpen ? (
                <AskExprtScreenNew
                  modelOpen={this.state.isModelOpen}
                  title={this.state.modalTitle}
                  closeModal={this.close.bind(this)}
                  empdata={this.state.dtaarr}
                  sendQueryToexpert={this.sendQueryToexpert.bind(this)}
                />
              ) : null}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

AskexpertNew.propTypes = {
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    expertBySkill: state.askExpertReducer.expertBySkill || [],
    querysendStatus: state.askExpertReducer.querysendStatus || [],
    allskills: state.skillReducer.allskills || []
  };
};

export default connect(mapStateToProps)(AskexpertNew);
