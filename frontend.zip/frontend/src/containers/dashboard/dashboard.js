//This component is developed to dispaly users skills in single view.  User has facility to view 	his /her skill and skill count according to his/her expertise level.
// Dashboad component has 	facility to add new skill. The tab view in the component  has 3 tabs which divides employee 	skills in Expert, Intermeddiate and Novice level.
//This tabs has functionality to edit and 	delete skills. The tabs shows unapproved and approved skills. Skills marked with color are 	unapproved.

import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import Chart from "react-google-charts";
import SimpleTabs from "../../components/tabs/tabs";
import Header from "../../components/header/header";
import { getAllUserInfo } from "../profile/profileActions";
import { getAllSkillsByLevel } from "./dashboardAction";
import { setAllMessage } from "../dashboardskill/dashboardSkillActions";
import threestars from "../../assets/images/3star.png";
import twostars from "../../assets/images/2star.png";
import onestar from "../../assets/images/1star.png";
import questionmark from "../../assets/images/questionmark.png";
import { NavLink } from 'react-router-dom';
import {Headers} from '../../config'
import "react-md/dist/react-md.pink-blue.min.css";
import "./dashboard.css";
import "../../assets/css/common.css";
import { Redirect } from "react-router-dom";

class DashboardComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expert: 0,
      practitioner: 0,
      novice: 0
    };
  }

  chartData = [0];
  chartOptions = {
    pieHole: 0.7,
    legend: "none",
    colors: ["#02c155", "#faa519", "#30a1d4"],
    pieSliceTextStyle: {
      color: 'transparent',
    }
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(getAllSkillsByLevel());
    dispatch(getAllUserInfo());
    dispatch(setAllMessage());
  }

  render() {

    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }
    const { users } = this.props;
    let keys = Object.keys(this.props.employeeSkillsByLevel);
    let len = 0;
    if (keys.length)
    {
      this.chartData = [
        ["skilllevel", "numberofskill"],
        ["Expert", this.props.employeeSkillsByLevel.Expert.length],
        ["Practitioner", this.props.employeeSkillsByLevel.Practitioner.length],
        ["Novice", this.props.employeeSkillsByLevel.Novice.length]
      ];
      for (let key of keys)
      {
        len += this.props.employeeSkillsByLevel[key].length;
        if (key == "Novice")
          this.state.novice = this.props.employeeSkillsByLevel[key].length;
        if (key == "Expert")
          this.state.expert = this.props.employeeSkillsByLevel[key].length;
        if (key == "Practitioner")
          this.state.practitioner = this.props.employeeSkillsByLevel[
            key
          ].length;
      }
    }

    return (
      <div className="">
        <div>
          <Header />
        </div>
        <div className="col-md-12 dashboard-container">
          <h2 className="dashboard-page-title">My Skills</h2>
          <div className="row dash-sec1">
            <div className="col-lg-3 col-12 box">
              <Chart
                chartType="PieChart"
                width="100%"
                height="350px"
                data={this.chartData}
                options={this.chartOptions}
              />
              <div className="charts-data-inside">
                <h2>{this.state.novice + this.state.expert + this.state.practitioner}</h2>
                <h4>Total Skills</h4>
              </div>
            </div>

            <div className="col-lg-3 col-4 box">
              <div className="skillbox expertbox">
                <div className="row">
                  <div className="col">
                    <span className="skillbox-count expertcount">
                      {this.state.expert}
                    </span>
                  </div>
                  <div className="skillbox-circle expert-circle-star">
                    <img
                      src={threestars}
                      alt="3 stars"
                      className="img-fluid"
                    />
                  </div>
                </div>
                <h6> Expert</h6>
              </div>
            </div>

            <div className="col-lg-3 col-4 box">
              <div className="skillbox practitionerbox">
                <div className="row">
                  <div className="col">
                    <span className="skillbox-count practitionercount">
                      {this.state.practitioner}
                    </span>
                  </div>
                  <div className="skillbox-circle practitionerbox-circle-star">
                    <img
                      src={twostars}
                      alt="2 stars"
                      className="img-fluid"
                    />
                  </div>
                </div>
                <h6>Practitioner</h6>
              </div>
            </div>

            <div className="col-lg-3 col-4 box">
              <div className="skillbox novicebox">
                <div className="row">
                  <div className="col">
                    <span className="skillbox-count novicecount">
                      {this.state.novice}
                    </span>
                  </div>
                  <div className="skillbox-circle novice-circle-star">
                    <img
                      src={onestar}
                      alt="1 star"
                      className="img-fluid"
                    />
                  </div>
                </div>
                <h6> Novice</h6>
              </div>
            </div>
          </div>

          <div className="dash-tabs">
            <SimpleTabs
              childData={this.props.employeeSkillsByLevel['Expert']}
              practitionerData={
                this.props.employeeSkillsByLevel['Practitioner']
              }
              noViceData={this.props.employeeSkillsByLevel['Novice']}
            />
          </div>
        </div>
        <div />
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    users: state.profileReducer.users || [],
    employeeSkillsByLevel: state.dashboardReducer.employeeSkillsByLevel || [],
    editinfo: state.dashboardskillReducer.editinfo || "",
    deleteinfo: state.dashboardskillReducer.deleteinfo || ""
  };
};

export default connect(mapStateToProps)(DashboardComponent);
