import * as actionTypes from "./dashboardActionTypes";
import axios from "axios";
import { func } from "prop-types";
import { API_URL, Headers } from "./../../config";

export function getAllSkillsByLevel() {
  const headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  }
  return function (dispatch) {
    return axios
      .get(`${API_URL}/api/employee/getSkillsByLevel`, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_SKILL_BY_LEVEL,
          payload: res.data.data
        });
      });
  };
}