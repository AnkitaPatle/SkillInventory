import axios from "axios";
import * as actionTypes from "./dashboardSkillActionTypes";
import { toastr } from 'react-redux-toastr';
import { API_URL } from "./../../config";

export function editSkill(editSkill) {
  return function (dispatch) {
    const headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .put(
        API_URL + "/api/employee/editEmployeeSkill",
        { editSkill },
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.EDIT_SKILL,
          payload: { data: res.data.data }
        });
        toastr.success('Success', "Skill updated successfully.", { showCloseButton: false,
          timeOut: 3000 });
      });
  };
}

export function deleteSkill(deleteSkill) {
  return function (dispatch) {
    const headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + "/api/employee/deleteEmployeeSkill",
        { deleteSkill },
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.DELETE_SKILL,
          payload: { data: res.data.data }
        });
      });
  };
}

export function setAllMessage() {
  return function (dispatch) {
    dispatch({
      type: actionTypes.CHANGE_NOTIFICATION_STATUS,
      payload: { editinfo: "", deleteinfo: "" }
    });
  };
}
