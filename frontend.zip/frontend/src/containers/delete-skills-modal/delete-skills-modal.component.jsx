import React from 'react';
import Modal from 'react-bootstrap/Modal';
import './delete-skills-modal.style.css';

export const DeleteSkillsModal = ({closeDeleteSkillsModal, show, handleDelete, skillname}) => {
    return (
        <Modal show={show} onHide={closeDeleteSkillsModal} centered className="delete-skill-modal" backdrop="static">
            <Modal.Header>
                <Modal.Title>Delete Skills</Modal.Title>
                <span className="close" onClick={closeDeleteSkillsModal}>
                    <span>&times;</span>
                </span>
            </Modal.Header>
            <Modal.Body>
                Are you sure you want to delete <span className="text-capitalize">"{skillname}"</span> Skill?
            </Modal.Body>
            <Modal.Footer>
                <button onClick={closeDeleteSkillsModal} className="delete-skill-action-no">
                    No
                </button>
                <button onClick={handleDelete} className="delete-skill-action-yes">
                    Yes
                </button>
            </Modal.Footer>
        </Modal>
    )
}