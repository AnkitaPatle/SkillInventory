import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";

import { getAllSkills } from "../skill/skillActions";
import Routing from "../../routing";
import Header from "../../components/header/header";
import * as actions from "../skill/skillActions";
import "../skill/skill.css";

const minOffset = 0;
const maxOffset = 20;
const thisYear = new Date().getFullYear();

class AddskillsComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      skillName: "",
      expertiseLevel: "",
      currentStatus: "",
      thisYear: thisYear,
      selectedYear: thisYear,
      message: "",
      directName: ""
    };
  }

  submitAllSkillInfo(e) {
    const employeeSkill = {
      skillName: this.state.skillName,
      expertiseLevel: this.state.expertiseLevel,
      currentStatus: this.state.currentStatus,
      year: this.state.selectedYear,
      directName: this.state.directName
    };

    const { dispatch } = this.props;
    dispatch(actions.createSkills(employeeSkill));
    this.clearAllFields();
  }

  clearAllFields = () => {
    this.setState({ skillName: "" });
    this.setState({ expertiseLevel: "" });
    this.setState({ currentStatus: "" });
    this.setState({ selectedYear: thisYear });
  };

  onChangeSkillName(e) {
    this.setState({ skillName: e.target.value });
    this.setState({ message: "" });
  }
  onChangeExpertiseLevel(e) {
    this.setState({ expertiseLevel: e.target.value });
    this.setState({ message: "" });
  }
  onChangeCurrentStatus(e) {
    this.setState({ currentStatus: e.target.value });
    this.setState({ message: "" });
  }
  onChangeSelectedYear(e) {
    this.setState({ selectedYear: e.target.value });
    this.setState({ message: "" });
  }
  onChangeDirect(e) {
    this.setState({ directName: e.target.value });
    this.setState({ message: "" });
  }

  render() {
    const { skills } = this.props;
    const { thisYear, selectedYear } = this.state;
    const options = [];
    for (let i = minOffset; i <= maxOffset; i++) {
      const year = thisYear - i;
      options.push(<option value={year}>{year}</option>);
    }
    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <div className="sectiontitle">
                <h2> Add Directs Skill </h2>
              </div>

              <div className="col-md-12">
                <div className="row">
                  <div className="col-md-12">
                    <div className="form-group">
                      <h3>Select Direct</h3>
                      <select
                        onChangeDirect={this.onChangeDirect.bind(this)}
                        name="directsname"
                        className="form-control col-md-3"
                      >
                        <option value="rahul chougule"> Rahul Chougule </option>
                        <option value=" rahul rokade"> Rahul Rokade </option>
                        <option value=" rohan rao"> Rohan Rao </option>
                      </select>
                    </div>

                    <div className="form-group col-md-4">
                      {this.state.message}
                      <h3>Skill Name</h3>
                      <input
                        type="text"
                        className="form-control searchtext"
                        name="skillName"
                        value={this.state.skillName}
                        onChange={this.onChangeSkillName.bind(this)}
                      />
                      <button className="btn btn-primary padding-left-50">
                        <i className="fa fa-search"> </i>
                      </button>
                    </div>
                  </div>

                  <div className="col-md-6 col-sm-6 col-xs-12">
                    <div className="form-group">
                      <label className="labeltext"> Expertise </label>
                      <br />
                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="expertiseLevel"
                          value="Expert"
                          onChange={this.onChangeExpertiseLevel.bind(this)}
                        />
                        <span class="checkround" />
                        Expert
                      </label>

                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="expertiseLevel"
                          value="Practitioner"
                          onChange={this.onChangeExpertiseLevel.bind(this)}
                        />
                        <span class="checkround" />
                        Practitioner
                      </label>
                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="expertiseLevel"
                          value="Novice"
                          onChange={this.onChangeExpertiseLevel.bind(this)}
                        />
                        <span class="checkround" />
                        Novice
                      </label>
                    </div>
                  </div>

                  <div className="col-md-6 col-sm-6 col-xs-12" />
                  <div className="col-md-6 col-sm-6 col-xs-12">
                    <div className="form-group">
                      <label className="labeltext">Status of Skillset</label>
                      <br />
                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="currentStatus"
                          value="Practicing"
                          onChange={this.onChangeCurrentStatus.bind(this)}
                        />
                        <span class="checkround" />
                        Practicing
                      </label>
                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="currentStatus"
                          value="Not Practicing"
                          onChange={this.onChangeCurrentStatus.bind(this)}
                        />
                        <span class="checkround" />
                        Not Practicing
                      </label>
                    </div>
                  </div>
                  <div className="col-md-6 col-sm-6 col-xs-12">
                    <div>
                      <h4> Last Practice </h4>
                      <select
                        defaultValue={this.state.selectedYear}
                        onChange={this.onChangeSelectedYear.bind(this)}
                        className="form-control col-md-2"
                      >
                        {options}
                      </select>
                    </div>
                  </div>
                </div>
                <button
                  onClick={this.submitAllSkillInfo.bind(this)}
                  className="btn btn-outline-primary btnadd"
                >
                  Add Skill Info
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

AddskillsComponent.propTypes = {
  skills: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  let skills = {};
  if (state.skillReducer.skills !== undefined) {
    skills = state.skillReducer;
    return skills;
  } else {
    return { skills };
  }
};

export default connect(mapStateToProps)(AddskillsComponent);
