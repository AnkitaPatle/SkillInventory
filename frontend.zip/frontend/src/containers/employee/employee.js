//This component contains the list all employees. Only CapDev Executive can view this list.
//This list provides employee name (corporate email of employee),  skill name ,  expertise 	level of skill, current status of skill, practicing year of skill.

import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { toastr } from "react-redux-toastr";
import Header from "../../components/header/header";
import Routing from "../../routing";
import TableHeader from "../../components/table/TableHeader";
import EmployeeRow from "../../components/table/employeeRow";
import * as actions from "../admin/role/assignRoleActions";
import StarRating from './../../components/starRating/starRating';
import { NavLink } from "react-router-dom";
import { withRouter } from 'react-router-dom';
import { Redirect } from "react-router-dom";
import "./style.css";
import Autosuggest from "react-autosuggest";
import { log } from "handlebars";
import * as skillsactions from "./../skill/skillActions";


let suggestedskills = [];
const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : suggestedskills.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;

class EmployeeComponent extends Component {
  constructor(props)
  {
    super(props);
    this.state = {
      data: [],
      empname: "",
      value: "",
        suggestions: [],
    };
  }
 
  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.getAllEmployeeListForCapdev(this.state.empname));
  }

  getManagerValue(e) {
    const user = {
      username: e.username,
      role: "Manager"
    };
    const { dispatch } = this.props;
    dispatch(actions.changeRole(user));
  }

  getCapDevValue(e) {
    const user = {
      username: e.username,
      role: "Capdev"
    };
    const { dispatch } = this.props;
    dispatch(actions.changeRole(user));
  }

  ratingCheck = (rating) => {
  }
  getEmployeeData = () => {
    if (this.state.empname !== "" && this.state.empname.trim()) {
      const { dispatch } = this.props;
      dispatch(actions.getAllEmployeeListForCapdev(this.state.empname));
    } else {
      toastr.warning("Warning!", "Please enter Employee Name or Skills and Press Search Button!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  }
  getempbyname = (e) => {
    this.setState({ empname: e.target.value });
  }
  renderOnEmployee = (e, empData) => {
    sessionStorage.setItem("empUsername", empData.username)
    this.props.history.push('/empProfile');
  }
  
  onSuggestionsFetchRequested = ({ value }) => {
       this.setState({
        srchval: value,
        suggestions: getSuggestions(value)
      })
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };

  onChange = (event, { newValue }) => {
    if(newValue === "")
    {
      const { dispatch } = this.props;
      dispatch(actions.getAllEmployeeListForCapdev(""));
    }
    this.setState({ value: newValue });
    this.setState({empname:newValue})
    const { dispatch } = this.props;
    const skillname = { skillname: event.target.innerText };
    dispatch(skillsactions.getAllSkillsFromCluster(skillname));
  };

  onKeyPress = e => {
    if (e.key === "Enter")
    {
      const { dispatch } = this.props;
      dispatch(actions.getAllEmployeeListForCapdev(this.state.empname));
    }
  };

  render() {
    if (!localStorage.getItem("token")) {
      return <Redirect to="/" />;
    }
    suggestedskills = this.props.allskills;
    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: "Search by Employee name or Skills! ",
      value,
      onChange: this.onChange,
      onKeyPress: this.onKeyPress
    };

    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <div className="col-xl-3 col-lg-4 col-md-6 col-sm-6 form-group">
                <h1 className="dashboard-page-title">Employee</h1>
                <div class="add-skill-autosuggest-container input-group mb-3 employee-list-container">

                  <Autosuggest
                    suggestions={suggestions}
                    onSuggestionsFetchRequested={
                      this.onSuggestionsFetchRequested
                    }
                    onSuggestionsClearRequested={
                      this.onSuggestionsClearRequested
                    }
                    getSuggestionValue={getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                    inputProps={inputProps}
                    name="skillname"
                    value={this.state.value}
                    className="col-md-4 form-control"
                  />
                  <div class="input-group-append">
                    <button className="btn btn-add" onClick={this.getEmployeeData}>
                      <i className="fa fa-search btn-add-icon" aria-hidden="true"></i>
                    </button>
                  </div>
                </div>
              </div>
              <div className="colorcombo">
                {this.props.roleStatus.data != "" ? (
                  this.props.roleStatus.data
                ) : (
                    ""
                  )}
              </div>
              <br />
              <div className="col-md-12">
                <table className="table">
                  <thead>
                    <tr className="hideMob">
                      <th width = "10%">SR. NO.</th>
                      <th width = "22%">EMPLOYEE NAME</th>
                      <th width = "22%">MANAGER</th>
                      <th width = "22%">ROLE</th>
                      <th width = "24%">SKILLS</th>

                      {/* <th style={{ maxWidth: "80px", minWidth: "80px", width: "80px" }}>SR. NO.</th>
                      <th style={{ maxWidth: "400px", minWidth: "400px", width: "400px" }}>EMPLOYEE NAME</th>
                      <th style={{ maxWidth: "450px", minWidth: "450px", width: "450px" }}>MANAGER</th>
                      <th style={{ maxWidth: "200px", minWidth: "200px", width: "200px" }}>ROLE</th>
                      <th style={{ maxWidth: "100%", minWidth: "100%", width: "100%" }}>Skills</th> */}
                      {/* <th>EXPERTISE LEVEL</th>
                    <th>STATUS OF SKILL</th> */}
                    </tr>
                  </thead>
                  <tbody>
                    {this.props.employeeList.length > 0 ? this.props.employeeList.map((items, key) => {
                      let manager = '';
                      items.managers && items.managers !== 0 ?
                        manager = (items.managers.toUpperCase()) :
                        manager = '-. @mail.com';
                      return (
                        <tr>
                          <td className="hideMob">{key + 1}</td>
                          <td className="hideMob"><span className="textcolor" onClick={e => this.renderOnEmployee(e, items)}>{items.firstname} {items.lastname}</span></td>
                          <td className="hideMob">{manager.split('.')[0] + ' ' + manager.split('.')[1].split('@')[0]}</td>
                          <td className="hideMob">{items.role}</td>
                          <td>
                            <div className="hideMob">
                            {items.skills.map((skills, key) =>
                              skills.level === "Novice" ? (
                                <span key={key} style={{ color: "#30a1d4" }}>
                                  {(key ? ", " : "") + skills.skillname}
                                </span>
                              ) : skills.level === "FPractitioner" ? (
                                <span key={key} style={{ color: "#faa519" }}>
                                  {(key ? ", " : "") + skills.skillname}
                                </span>
                              ) : (
                                    <span key={key} style={{ color: "#02c155" }}>
                                      {(key ? ", " : "") + skills.skillname}
                                    </span>
                                  )
                            )}
                            </div>

                            <div className="showMob flex-column">
                              <div><span className="textcolor" onClick={e => this.renderOnEmployee(e, items)}>{items.firstname} {items.lastname}</span></div>
                              <div><b>Manager:</b> {manager.split('.')[0] + ' ' + manager.split('.')[1].split('@')[0]}</div>
                              <div><b>Role:</b> {items.role}</div>
                              <div><b>Skills:</b>
                                {items.skills.map((skills, key) =>
                                  skills.level === "Novice" ? (
                                    <span key={key} style={{ color: "#30a1d4" }}>
                                      {(key ? ", " : "") + skills.skillname}
                                    </span>
                                  ) : skills.level === "FPractitioner" ? (
                                    <span key={key} style={{ color: "#faa519" }}>
                                      {(key ? ", " : "") + skills.skillname}
                                    </span>
                                  ) : (
                                        <span key={key} style={{ color: "#02c155" }}>
                                          {(key ? ", " : "") + skills.skillname}
                                        </span>
                                      )
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      );
                    }) : <tr><td className="tableStyle"> No data available!</td> </tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>
          </div>    
          </div>    
      </div>
    );
  }
}

EmployeeComponent.propTypes = {
  getAllEmployeeList: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    employeeList: state.assignRoleReducer.employeeList || [],
    roleStatus: state.assignRoleReducer.managerRoleSuccess || "",
    allskills: state.skillReducer.allskills || []
  };
};

export default connect(mapStateToProps)(withRouter(EmployeeComponent));
