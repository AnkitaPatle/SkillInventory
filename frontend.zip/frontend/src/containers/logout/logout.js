import React, { Component } from "react";
import "./logout.css";
import { withRouter, Redirect } from "react-router-dom";
class LogoutComponent extends Component {
  componentDidMount() {
    const rememberMe = localStorage.getItem("rememberMe") == 'true';
    const UserName = rememberMe ? localStorage.getItem("UserName") : "";
    const Password = rememberMe ? localStorage.getItem("Password") : "";
    localStorage.clear();    
    sessionStorage.clear();
    if (rememberMe) {
      localStorage.setItem("rememberMe", rememberMe);
      localStorage.setItem("UserName", UserName);
      localStorage.setItem("Password", Password);
    }
    this.props.history.push("/");
  }

  render() {
    if (!localStorage.getItem("token")) {
      return <Redirect to="/" />;
    }
    return null;
  }
}

export default withRouter(LogoutComponent);
