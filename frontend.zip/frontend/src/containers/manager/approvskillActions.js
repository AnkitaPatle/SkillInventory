import axios from "axios";
import * as actionTypes from "./approveskillActionTypes";
import { toastr } from "react-redux-toastr";
import { API_URL } from "./../../config";
import { getAllDirectsforApproveAll } from './mydirects/mydirectsActions';

export function DirectList() {
  return function (dispatch) {
    const headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .get(API_URL + "/api/manager/employeesUnderManager", {
        headers: headers
      })
      .then(res => {
        dispatch({
          type: actionTypes.DIRECT_LIST,
          payload: { data: res.data.data, message: "All Skill Approve successfully.", addmessage: "Skill Added Successfully." }
        });
      });
  };
}

export function ApproveSkill(skillinfo) {
  return function (dispatch) {
    const headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + "/api/manager/approveSkill/" +
        skillinfo.username +
        "/" +
        skillinfo.skillname,
        { headers: headers }
      )
      .then(res => { });
  };
}

export function ApproveMultipleSkills(skillinfo) {
  return function (dispatch) {
    const headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + "/api/manager/approveMultipleSkills",
        { skillinfo: skillinfo },
        { headers: headers }
      )
      .then(res => {
        dispatch(DirectList());
        // toastr.success("Success", "Skills approved successfully.", {
        //   showCloseButton: false,
        //   timeOut: 3000
        // });
      });
  };
}
export function AddDirectSkills(skillinfo) {
  return function (dispatch) {
    const headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + "/api/manager/addDirectSkill",
        { skillinfo: skillinfo },
        { headers: headers }
      )
      .then(res => {
        dispatch(DirectList());
      });
  };
}

export function sendCommentToEmployee(skillinfo) {
  return function (dispatch) {
    const headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + "/api/manager/commentSkill",
        { skillinfo },
        { headers }
      )
      .then(res => {
        dispatch(DirectList());
        dispatch(getAllDirectsforApproveAll());
      });
  };
}
