import React, { Component } from "react";
import "./../../../components/tabs/editComponent.style.css";
import Modal from "react-bootstrap/Modal";
import Autosuggest from "react-autosuggest";
import * as actions from "./../../../containers/skill/skillActions";
import { connect } from "react-redux";
import StarRating from "./../../../components/starRating/starRatingNew";
import ReactHover from 'react-hover';
import { toastr } from "react-redux-toastr";
import skillReducer from './../../../containers/skill/skillReducers';
import ReactTooltip from 'react-tooltip'

const customStyles = {
};

const minOffset = 0;
const maxOffset = 20;
const thisYear = new Date().getFullYear();

let suggestedskills = [];
const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : suggestedskills.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;
// const optionsCursorTrueWithMargin = {
//   followCursor: true,
//   shiftX: 20,
//   shiftY: 0
// }
let experiencedList = [{ years: "0 to 0.5 Yrs" }, { years: "0.5 to 1 Yrs" }, { years: "1 to 3 Yrs" }, { years: "3 to 5 Yrs" }, { years: "5 to 10 Yrs" }, { years: "10 to 15 Yrs" }, { years: "15 to 20 Yrs" }, { years: "20 And Above" }];

class AddSkillDm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalIsOpen: this.props.modelOpen ? true : false,
      skillName: this.props.selectedData
        ? this.props.selectedData.skillname
        : "",
      expertiseLevel: this.props.selectedData
        ? this.props.selectedData.level
        : "",
      currentStatus: this.props.selectedData
        ? this.props.selectedData.currentStatus
        : "",
      thisYear: thisYear,
      selectedYear: this.props.selectedData
        ? this.props.selectedData.year
        : thisYear,
      message: "",
      addDirectSkill: this.props.addDirectSkill
        ? this.props.addDirectSkill
        : { username: "", status: "" },
      skillname: "",
      suggestions: [],
      value: "",
      experience: "0 to 0.5 Yrs",
      currentStatusNew: "Not Practising  ",
      disabled: false,
      skilllevel: "Average",
      hovermessage: "currently learning",
      disable:false,
       createdDate: this.props.selectedData
        ? this.props.selectedData.createdDate
        : "",
    };
    this.openModal = this.openModal.bind(this);
    this.afterOpenModal = this.afterOpenModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.cancelModal = this.cancelModal.bind(this);
    this.textInput = React.createRef();
  }

  onChangeSkillName(e) {
    this.setState({ skillName: e.target.value });
    this.setState({ expertiseLevel: e.target.value });
    this.setState({ message: "" });
  }

  onChangeExpertiseLevel(rating) {
    this.setState({ expertiseLevel: rating });
    this.setState({ message: "" });
  }
  onChangeCurrentStatus(e) {
    this.state.disabled = !this.state.disabled;
    if (this.state.disabled === true)
    {
      document.getElementById("year").value = thisYear;
      this.setState({ selectedYear: thisYear });
    }
    this.setState({ currentStatusNew: e.target.value })
    this.setState({ message: "" });
  }
  onChangeSelectedYear(e) {
    this.setState({ selectedYear: e.target.value });
    this.setState({ message: "" });
  }

  openModal() {
    this.setState({ modalIsOpen: true });
  }

  afterOpenModal() {
    this.subtitle.style.color = "#f00";
  }

  closeModal(e) {
    if (this.props.selectedData.skillname === this.state.skillName)
    {
      const skillinfo = {
        skillname: this.state.skillName,
        level: this.state.expertiseLevel,
        currentStatus: this.state.currentStatusNew,
        year: this.state.selectedYear,
        experience: this.state.experience,
        createdDate: this.state.createdDate,
      };
      this.props.updateSkill(skillinfo);
    }
  }
  cancelModal() {
    if (this.state.addDirectSkill.status === "A")
    {
      return this.props.close();
    } else
    {
      return this.props.closeeditbox();
    }
  }
  skillname(e) {
    this.setState({ skillName: e.target.value });
  }
  addSkill = e => {
    this.setState({disable:true})
    const skillinfo = {
      skillname: this.state.skillName.skillname,
      level: this.state.expertiseLevel,
      currentStatus: this.state.currentStatusNew,
      year: this.state.selectedYear,
      username: this.props.addDirectSkill.username,
      skillStatus: "approved",
      experience: this.state.experience,
      createdDate: new Date(),
      comment:"-"
    };
if(skillinfo.skillname === undefined){
  toastr.warning("Warning!", "Please add skill name!", {
            showCloseButton: false,
            timeOut: 3000
          });
}
else  {
  const { dispatch } = this.props;

  dispatch(actions.validateSkillsFromMaster(skillinfo.skillname ,this.props.addDirectSkill.username)).then((res) =>{
    if(this.props.masterValidateSkill && this.props.masterValidateSkill === "No skills found")
    {
        this.props.addSkillDirect(skillinfo);
    }
    else{
      const skillInfoName = skillinfo.skillname && skillinfo.skillname.charAt(0).toUpperCase() + skillinfo.skillname.slice(1);
      toastr.warning("Warning!", `Skill "${skillInfoName}" already present, Please enter different skill!`, {
            showCloseButton: false,
            timeOut: 3000
          });
    }
    this.setState({disable:false})
  });
}  
  };
  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: getSuggestions(value)
    });
  };
  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };

  onChange = (event, { newValue }) => {
    let input = event.target.innerText;
    let name = event.target.innerText;
    let skillvalue = input.value;
    this.setState({
      [name]: skillvalue
    });
    this.setState({ value: newValue });
    const { dispatch } = this.props;
    const skillname = { skillname: newValue };
    this.setState({ skillName: skillname });
    dispatch(actions.getAllSkillsFromCluster(skillname));
  };
  selectChangesExperienced = (e) => {
    this.setState({ experience: e.target.value })
  }
  render() {
    suggestedskills = this.props.allskills;
    const { skills } = this.props;
    const { thisYear, selectedYear, suggestions, value } = this.state;
    const options = [];
    for (let i = minOffset; i <= maxOffset; i++)
    {
      const year = thisYear - i;
      options.push(<option value={year}>{year}</option>);
    }
    const inputProps = {
      placeholder: "Enter skill",
      value,
      onChange: this.onChange
    };

    return (
      <Modal backdrop="static"
        show={this.state.modalIsOpen}
        onHide={this.cancelModal}
        className={
          "skill-modal " +
          (this.state.addDirectSkill.status === "A"
            ? "add-skill-modal"
            : "edit-skill-modal")
        }
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {this.state.addDirectSkill.status === "A"
              ? "Add Skill"
              : "Edit Skills"}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-sm-6 mb-3">
              <div>
                <p className="modal-label-title">Skillset</p>
                {this.state.addDirectSkill.status === "A" ? (
                  <div>
                    <Autosuggest
                      suggestions={suggestions}
                      onSuggestionsFetchRequested={
                        this.onSuggestionsFetchRequested
                      }
                      onSuggestionsClearRequested={
                        this.onSuggestionsClearRequested
                      }
                      getSuggestionValue={getSuggestionValue}
                      renderSuggestion={renderSuggestion}
                      inputProps={inputProps}
                      name="skillname"
                      value={this.state.value}
                      className="col-md-4 form-control"
                    />
                  </div>
                ) : (
                    <div className="modal-label-value">
                      {this.state.skillName}
                    </div>
                  )}
              </div>
            </div>

            <div className="col-sm-6 mb-3">
              <div className="form-group">
                <p className="modal-label-title">
                  Expertise Level
                </p>
                <div>                      
                      <StarRating
                        handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                        rating={this.state.expertiseLevel}>
                      </StarRating>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-sm-6 mb-3">
              <p class="modal-label-title">Practising</p>
               <div className ="custom-control custom-checkbox custom-checkbox-field">
                        <input className="form-control custom-control-input"
                          type="checkbox"
                          name={"currentStatus"}
                          value="Practising"
                          onChange={this.onChangeCurrentStatus.bind(this)}
                        />  
                            <label class="custom-control-label" for={"chkboxm"}></label>
                            </div>
            </div>
            <div className="col-sm-4 mb-3">
              <div>
                <p className="modal-label-title">Last Used</p>
                <select
                  defaultValue={this.state.selectedYear}
                  onChange={this.onChangeSelectedYear.bind(this)}
                  className="form-control"
                  disabled={this.state.disabled}
                  id="year"

                >
                  {options}
                </select>
              </div>
            </div>

            <div className="col-sm-4 mb-3">
              <div>
                <p className="modal-label-title">Experience </p>
                <select
                  defaultValue={this.state.selectedExperience}
                  className="form-control"
                  onChange={e => this.selectChangesExperienced(e)}
                >
                  {experiencedList.map((item, key) => (
                    <option value={item.years}>{item.years}</option>
                  ))}

                </select>
              </div>
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button
            onClick={this.cancelModal}
            className="edit-skill-action-cancel"
          >
            {" "}
            Cancel{" "}
          </button>
          {this.state.addDirectSkill.status === "A" ? (
            <button
              className="edit-skill-action-save-add"
              onClick={e => this.addSkill(e)}
              disabled = {this.state.disable} 
            >
              {" "}
              Add{" "}
            </button>
          ) : (
              <button
                className="edit-skill-action-save"
                onClick={this.closeModal}
              >
                {" "}
                Update{" "}
              </button>
            )}
        </Modal.Footer>
      </Modal>
    );
  }
}

const mapStateToProps = state => {
  return {
    allskills: state.skillReducer.allskills || [],
    masterValidateSkill:state.skillReducer.masterValidateSkill || []
  };
};
export default connect(mapStateToProps)(AddSkillDm);