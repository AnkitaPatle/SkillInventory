import * as actionTypes from "./employeeProfileActionTypes";
import axios from "axios";
import { func } from "prop-types";
import { API_URL } from "./../../../../config";


export function getAllUserInfo(username) {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };

    return axios
      .post(API_URL + `/api/employee/userDetails`, { username: username }, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_USER_SUCCESS_FOR_EMP,
          payload: res.data.data
        });
      });
  };
}


export function getAllSkillsByLevel(username) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/employee/getSkillsByLevelEmp`, { username: username }, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_SKILL_BY_LEVEL_FOR_EMP,
          payload: res.data.data
        });
      });
  };
}
