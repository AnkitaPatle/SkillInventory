import * as actionTypes from "./employeeProfileActionTypes";
const employeeProfileReducer = (state = {}, action) => {
  switch (action.type)
  {
    case actionTypes.FETCH_USER_SUCCESS_FOR_EMP:
      return Object.assign({}, state, {
        userDetailsEmployee: action.payload
      });
    case actionTypes.FETCH_SKILL_BY_LEVEL_FOR_EMP:
      return Object.assign({}, state, {
        employeeSkillsByLevelEmoloyee: action.payload
      });
    default:
      return state;
  }
};
export default employeeProfileReducer;
