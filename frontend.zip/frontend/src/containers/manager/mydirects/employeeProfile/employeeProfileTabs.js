// This component contains tabs which are displayed on dashboard
import React from "react";
import PropTypes from "prop-types";
import { NavLink, Link } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import "./../../../../components/tabs/tabs.css";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import { toastr } from "react-redux-toastr";
import { API_URL } from './../../../../config';
import StarRating from "./../../../../components/starRating/starRating";

function TabContainer(props) {
    return (
        <Typography component="div" style={{ padding: 8 * 0 }}>
            {props.children}
        </Typography>
    );
}

TabContainer.propTypes = {
    children: PropTypes.node.isRequired
};

const styles = theme => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
        margin: "50px 0",
        background: "#eeeeee"
    },
    indicator: {
        backgroundColor: "#0693e8"
    },
    flexContainer: {
        borderBottom: "1px solid #f4f4f4"
    },
    tabRoot: { borderColor: "#fff" }
});

class EmployeeProfileTabs extends React.Component {
    state = {
        value: 0,
        addYearList: [],
        isModalOpen: false,
    };
    handleChange = (event, value) => {
        this.setState({ value });
    };
    getEmployeeInfo = (data) => {
    }
    onChangeExpertiseLevel(rating) {
        this.setState({ expertiseLevel: rating });
        this.setState({ message: "" });
    }
    render() {
        const userdata = this.props.allUserData;
        const { classes } = this.props;
        const { value } = this.state;

        return (
            <div className={classes.root}>
                <AppBar position="static">
                    <div className="row tabs">
                        <div className="col-md-9 tabmenu">
                            <Tabs
                                value={value}
                                onChange={this.handleChange}
                                classes={{
                                    indicator: classes.indicator,
                                    flexContainer: classes.flexContainer
                                }}
                            >
                                <Tab id="expert"
                                    label="Expert"
                                    className="expert"
                                    classes={{ root: classes.tabRoot }}

                                />
                                <Tab id="practitioner" label="Practitioner" className="practitioner" />
                                <Tab id="novice" label="Novice" className="novice" />
                            </Tabs>
                        </div>
                        <div className="col-md-3 newskillbutton">
                        </div>
                    </div>
                </AppBar>

                {value === 0 && (
                    <TabContainer>
                        <table className="table dashboard-skill-table">
                            <tbody>
                                <tr className="hideMob">
                                    <th style={{width:"10%"}}>EMPLOYEE NAME</th>
                                    <th style={{width:"10%"}}>SKILLSET</th>
                                    {/* <th>ROLE</th> */}
                                    <th style={{width:"10%"}}>EXPERTISE LEVEL</th>
                                    <th style={{width:"10%"}}>EXPERIENCE</th>
                                    <th style={{width:"10%"}}>PRACTICING</th>
                                    <th style={{width:"10%"}}>DM COMMENTS</th>
                                    <th style={{width:"10%"}}>LAST USED</th>
                                </tr>
                                {this.props.childData != undefined ? (
                                    this.props.childData.map((ele, i) => (
                                        <tr className={ele.skillStatus === "pending" ? "pending-notation" : ""} >
                                            <td className="">
                                                <div className="hideMob">
                                                <div class="table-skillset ask-expert-table-col-name">
                                                    <span onClick={this.getEmployeeInfo.bind(this, ele)} className="textcoloremp">{userdata.firstname} {userdata.lastname}</span>
                                                </div></div>
                                                 <div className="showMob flex-column">
                                                    <div className="table-skillset ask-expert-table-col-name">                                                   
                                                        <span onClick={this.getEmployeeInfo.bind(this, ele)} className="textcolor">{userdata.firstname} {userdata.lastname}</span>
                                                    </div>  
                                                        <div><b>Skillset: </b>{ele.skillname}</div>
                                                        <div><b>Expertise Level: </b>
                                                        <StarRating
                                                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                                                            rating={ele.level} disableClick={true}>
                                                        </StarRating>
                                                        </div>
                                                        <div><b>Experience: </b>{ele.experience}</div>
                                                        <div><b>Practicing: </b>{ele.currentStatus === "Practising" ? "Yes" : "No" }</div>
                                                        <div><b>Last used/Since using: </b>{ele.year}</div>                                                   
                                                </div>
                                            </td>

                                            <td className="hideMob">
                                                <div className="table-skillset">{ele.skillname} </div>
                                            </td>
                                            <td className="hideMob">
                                                <div>
                                                    <StarRating
                                                        handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                                                        rating={ele.level} disableClick={true}>
                                                    </StarRating>
                                                </div>
                                            </td>
                                            <td className="hideMob">
                                                <div className="table-skillset">{ele.experience}</div>
                                            </td>
                                            <td className="hideMob">
                                                {ele.currentStatus === "Practising" ? <div className="table-skillset">Yes</div> : <div className="table-skillset">No</div>}
                                            </td>

                                            <td className="hideMob">
                                                {ele.comment}
                                            </td>

                                            <td className="hideMob">
                                                <div className="table-skillset"> {ele.year}</div>
                                            </td>
                                        </tr>
                                    )
                                    )) : "No data to show.........!"}
                            </tbody>
                        </table>
                    </TabContainer>
                )}
                {value === 1 && (
                    <TabContainer>
                        <table className="table dashboard-skill-table">
                            <tbody>
                                <tr className="hideMob">
                                    <th style={{width:"10%"}}>EMPLOYEE NAME</th>
                                    <th style={{width:"10%"}}>SKILLSET</th>
                                    {/* <th>ROLE</th> */}
                                    <th style={{width:"10%"}}>EXPERTISE LEVEL</th>
                                    <th  style={{width:"10%"}}>EXPERIENCE</th>
                                    <th style={{width:"10%"}}>PRACTICING</th>
                                    <th style={{width:"10%"}}>DM COMMENTS</th>
                                    <th style={{width:"10%"}}>LAST USED</th>
                                </tr>
                                {this.props.practitionerData != undefined ? (
                                    this.props.practitionerData.map((ele, i) => (
                                        <tr className={ele.skillStatus === "pending" ? "pending-notation" : ""}>
                                            <td className="">
                                                <div className="hideMob">
                                                <div class="table-skillset ask-expert-table-col-name">
                                                    <span onClick={this.getEmployeeInfo.bind(this, ele)} className="textcoloremp">{userdata.firstname} {userdata.lastname}</span>
                                                </div></div>
                                                 <div className="showMob flex-column">
                                                    <div className="table-skillset ask-expert-table-col-name">                                                   
                                                        <span onClick={this.getEmployeeInfo.bind(this, ele)} className="textcolor">{userdata.firstname} {userdata.lastname}</span>
                                                    </div>  
                                                        <div><b>Skillset: </b>{ele.skillname}</div>
                                                        <div><b>Expertise Level: </b>
                                                        <StarRating
                                                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                                                            rating={ele.level} disableClick={true}>
                                                        </StarRating>
                                                        </div>
                                                        <div><b>Experience: </b>{ele.experience}</div>
                                                        <div><b>Practicing: </b>{ele.currentStatus === "Practising" ? "Yes" : "No" }</div>
                                                        <div><b>Last used/Since using: </b>{ele.year}</div>                                                   
                                                </div>
                                            </td>

                                            <td className="hideMob">
                                                <div className="table-skillset">{ele.skillname} </div>
                                            </td>
                                            <td className="hideMob">
                                                <div>
                                                    <StarRating
                                                        handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                                                        rating={ele.level} disableClick={true}>
                                                    </StarRating>
                                                </div>
                                            </td>
                                            <td className="hideMob">
                                                <div className="table-skillset">{ele.experience}</div>
                                            </td>
                                            <td className="hideMob">
                                                {ele.currentStatus === "Practising" ? <div className="table-skillset">Yes</div> : <div className="table-skillset">No</div>}
                                            </td>

                                            <td className="hideMob">
                                                {ele.comment}
                                            </td>
                                            <td className="hideMob">
                                                <div className="table-skillset"> {ele.year}</div>
                                            </td>
                                        </tr>
                                    )
                                    )) : "No data to show.........!"}
                            </tbody>
                        </table>
                    </TabContainer>
                )}

                {value === 2 && (
                    <TabContainer>
                        <table className="table dashboard-skill-table">
                            <tbody>
                                <tr className="hideMob">
                                    <th style={{width:"10%"}}>EMPLOYEE NAME</th>
                                    <th style={{width:"10%"}}>SKILLSET</th>
                                    {/* <th>ROLE</th> */}
                                    <th style={{width:"10%"}}>EXPERTISE LEVEL</th>
                                    <th style={{width:"10%"}}>EXPERIENCE</th>
                                    <th style={{width:"10%"}}>PRACTICING</th>
                                    <th style={{width:"10%"}}>DM COMMENTS</th>
                                    <th style={{width:"10%"}}>LAST USED</th>
                                </tr>
                                {this.props.noViceData != undefined ? (
                                    this.props.noViceData.map((ele, i) => (
                                        
                                        <tr className={ele.skillStatus === "pending" ? "pending-notation" : ""}>
                                            <td className="">
                                                <div className="hideMob">
                                                <div class="table-skillset ask-expert-table-col-name">
                                                    <span onClick={this.getEmployeeInfo.bind(this, ele)} className="textcoloremp">{userdata.firstname} {userdata.lastname}</span>
                                                </div></div>
                                                <div className="showMob flex-column">
                                                    <div className="table-skillset ask-expert-table-col-name">                                                   
                                                        <span onClick={this.getEmployeeInfo.bind(this, ele)} className="textcolor">{userdata.firstname} {userdata.lastname}</span>
                                                    </div>  
                                                        <div><b>Skillset: </b>{ele.skillname}</div>
                                                        <div><b>Expertise Level: </b>
                                                        <StarRating
                                                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                                                            rating={ele.level} disableClick={true}>
                                                        </StarRating>
                                                        </div>
                                                        <div><b>Experience: </b>{ele.experience}</div>
                                                        <div><b>Practicing: </b>{ele.currentStatus === "Practising" ? "Yes" : "No" }</div>
                                                        <div><b>Last used/Since using: </b>{ele.year}</div>                                                   
                                                </div>
                                            </td>

                                            <td className="hideMob">
                                                <div className="table-skillset">{ele.skillname} </div>
                                            </td>
                                            <td className="hideMob">
                                                <div>
                                                    <StarRating
                                                        handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                                                        rating={ele.level} disableClick={true}>
                                                    </StarRating>
                                                </div>
                                            </td>
                                            <td className="hideMob">
                                                <div className="table-skillset">{ele.experience}</div>
                                            </td>
                                            <td className="hideMob">
                                                {ele.currentStatus === "Practising" ? <div className="table-skillset">Yes</div> : <div className="table-skillset">No</div>}
                                            </td>

                                            <td className="hideMob">
                                                {ele.comment}
                                            </td>

                                            <td className="hideMob">
                                                <div className="table-skillset"> {ele.year}</div>
                                            </td>
                                        </tr>
                                    )
                                    )) : "No data to show.........!"}
                            </tbody>
                        </table>
                    </TabContainer>
                )}
            </div>
        );
    }
}

EmployeeProfileTabs.propTypes = {
    classes: PropTypes.object.isRequired,
    dispatch: PropTypes.func.isRequired
};

export default withStyles(styles)(EmployeeProfileTabs);
