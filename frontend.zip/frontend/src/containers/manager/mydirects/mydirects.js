import React, { Component } from "react";
import { withRouter } from 'react-router-dom';
import Autosuggest from "react-autosuggest";
import DataTable from "react-data-table-component";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import * as actions from "./mydirectsActions";
import Header from "../../../components/header/header";
import "./mydirect.css";
import Chart from "react-google-charts";
import MydirectsTabs from "../../../components/tabs/mydirectsTabs";
import threestars from "../../../assets/images/3star.png";
import twostars from "../../../assets/images/2star.png";
import onestar from "../../../assets/images/1star.png";
import { Redirect, NavLink } from "react-router-dom";

let suggestednames = [];
const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : suggestednames.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};
const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;

class MydirectsComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "",
      suggestions: [],
      expert: 0,
      practitioner: 0,
      novice: 0,
      all: 0,
      redirect: false,
      reloaddata:""
    };
  }
  chartData = [];
  chartOptions = {
    pieHole: 0.7,
    legend: "none",
    colors: ["#02c155", "#faa519", "#30a1d4"],
    pieSliceTextStyle: {
      color: 'transparent',
    }
  };

  // to get list of all directs on load
  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.getAllDirects());
    dispatch(actions.getAllDirectsforApproveAll());
  }

  onChange = (event, { newValue }) => {
    let input = event.target;
    let name = event.target.name;
    let directNameValue = input.value;
    this.setState({
      [name]: directNameValue
    });
    this.setState({ value: newValue });
    const { dispatch } = this.props;
    const directName = { directName: newValue };
    dispatch(actions.getDirectDetails(directName));
  };

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: getSuggestions(value)
    });
  };
  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };

  approveSkills = () => { };

  reloaddata=()=>{
    const { dispatch } = this.props;
    dispatch(actions.getAllDirects());
    dispatch(actions.getAllDirectsforApproveAll());
    this.setState({reloaddata:"R"})
  }

  render() {
    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }

    let data;
    let item = this.props.getAllDirects;
    const { users } = this.props;
    let keys = Object.keys(this.props.getAllDirects);
    let len = 0;
    if (keys.length > 0)
    {
      if (this.props.getAllDirects.Expert === undefined)
      {
        if (this.props.getAllDirects.Practitioner === undefined)
        {
          if (this.props.getAllDirects.Novice === undefined)
          {
            this.chartData = [
              ["skilllevel", "numberofskill"],
              ["Expert", ""],
              ["Practitioner", ""],
              ["Novice", ""]
            ];
          }
          else
          {
            this.chartData = [
              ["skilllevel", "numberofskill"],
              ["Expert", ""],
              ["Practitioner", ""],
              ["Novice", this.props.getAllDirects.Novice.length]
            ];
          }
        }
        else
        {
          if (this.props.getAllDirects.Novice == undefined)
          {
            this.chartData = [
              ["skilllevel", "numberofskill"],
              ["Expert", ""],
              ["Practitioner", this.props.getAllDirects.Practitioner.length],
              ["Novice", ""]
            ];
          }
          else
          {
            this.chartData = [
              ["skilllevel", "numberofskill"],
              ["Expert", ""],
              ["Practitioner", this.props.getAllDirects.Practitioner.length],
              ["Novice", this.props.getAllDirects.Novice.length]
            ];
          }
        }
      }
      else if (this.props.getAllDirects.Practitioner === undefined)
      {
        if (this.props.getAllDirects.Novice === undefined)
        {
          this.chartData = [
            ["skilllevel", "numberofskill"],
            ["Expert", this.props.getAllDirects.Expert.length],
            ["Practitioner", ""],
            ["Novice", ""]
          ];
        }
        else
        {
          this.chartData = [
            ["skilllevel", "numberofskill"],
            ["Expert", this.props.getAllDirects.Expert.length],
            ["Practitioner", ""],
            ["Novice", this.props.getAllDirects.Novice.length]
          ];
        }
      }
      else if (this.props.getAllDirects.Novice === undefined)
      {
        this.chartData = [
          ["skilllevel", "numberofskill"],
          ["Expert", this.props.getAllDirects.Expert.length],
          ["Practitioner", this.props.getAllDirects.Practitioner.length],
          ["Novice", ""]
        ];
      }
      else
      {
        this.chartData = [
          ["skilllevel", "numberofskill"],
          ["Expert", this.props.getAllDirects.Expert.length],
          ["Practitioner", this.props.getAllDirects.Practitioner.length],
          ["Novice", this.props.getAllDirects.Novice.length]
        ];
      }

      for (let key of keys)
      {
        len += this.props.getAllDirects[key].length;
        if (key == "Novice")
          this.state.novice = this.props.getAllDirects[key].length;
        if (key == "Expert")
          this.state.expert = this.props.getAllDirects[key].length;
        if (key == "Practitioner")
          this.state.practitioner = this.props.getAllDirects[
            key
          ].length;
      }
    }
    item.length !== 0
      ? (data = [
        {
          id: item.id,
          employeename: item.name,
          role: item.role,
          expertiselevel: item.expertiselevel,
          statusofskillset: item.statusofskillset,
          lastused: item.lastused,
          action: "Add Skill"
        }
      ])
      : (data = "");
    const columns = [
      {
        name: "EMPLOYEE NAME",
        selector: "employeename",
        sortable: true
      },
      {
        name: "ROLE",
        selector: "role",
        sortable: true
      },
      {
        name: "EXPERTISE LEVEL",
        selector: "expertiselevel",
        sortable: true
      },
      {
        name: "STATUS OF SKILLSET",
        selector: "statusofskillset",
        sortable: true
      },
      {
        name: "LAST USED",
        selector: "lastused",
        sortable: true
      },
      {
        name: "ACTION",
        selector: "action",
        sortable: true
      }
    ];
    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: " Search by name, skillset",
      value,
      onChange: this.onChange
    };

    const BootyCheckbox = React.forwardRef(({ onClick, ...rest }, ref) => (
      <div className="custom-control custom-checkbox">
        <input
          type="checkbox"
          className="custom-control-input"
          ref={ref}
          {...rest}
        />
        <label
          className="custom-control-label custom-checkbox-label"
          onClick={onClick}
        />
      </div>
    ));

    return (
      <div className="">        
          <div>
            <Header />
          </div>

          <div className="col-md-12 dashboard-container">
            <h2 className="dashboard-page-title">My Directs</h2>
            <div className="row dash-sec1">
              <div className="col-lg-3 col-12 box">
                <div className="redline">
                <Chart
                  chartType="PieChart"
                  width="100%"
                  height="350px"
                  data={this.chartData}
                  options={this.chartOptions}
                />
                </div>
                <div className="charts-data-inside">
                  <h2>{this.state.novice + this.state.expert + this.state.practitioner}</h2>
                  <h4>Total Skills</h4>
                </div>
              </div>
              <div className="col-lg-3 col-4 box">
                <div className="skillbox expertbox">
                  <div className="row">
                    <div className="col">
                      <span className="skillbox-count expertcount">
                        {this.state.expert}
                      </span>
                    </div>
                    <div className="skillbox-circle expert-circle-star">
                      <img
                        src={threestars}
                        alt="3 stars"
                        className="img-fluid"
                      />
                    </div>
                  </div>
                  <h6> Expert</h6>
                </div>
              </div>

              <div className="col-lg-3 col-4 box">
                <div className="skillbox practitionerbox">
                  <div className="row">
                    <div className="col">
                      <span className="skillbox-count practitionercount">
                        {this.state.practitioner}
                      </span>
                    </div>
                    <div className="skillbox-circle practitionerbox-circle-star">
                      <img
                        src={twostars}
                        alt="2 stars"
                        className="img-fluid"
                      />
                    </div>
                  </div>
                  <h6>Practitioner</h6>
                </div>
              </div>

              <div className="col-lg-3 col-4 box">
                <div className="skillbox novicebox">
                  <div className="row">
                    <div className="col">
                      <span className="skillbox-count novicecount">
                        {this.state.novice}
                      </span>
                    </div>
                    <div className="skillbox-circle novice-circle-star">
                      <img
                        src={onestar}
                        alt="1 star"
                        className="img-fluid"
                      />
                    </div>
                  </div>
                  <h6> Novice</h6>
                </div>
              </div>
            </div>
            <div className="dash-tabs">
              <MydirectsTabs
                childData={this.props.getAllDirects['Expert']}
                practitionerData={
                  this.props.getAllDirects['Practitioner']
                }
                noViceData={this.props.getAllDirects['Novice']}
                alldata={this.props.allDirectsapproveall && this.props.allDirectsapproveall}
                dispatch={this.props.dispatch}
                reloaddata = {this.reloaddata}
              />
            </div>
          </div>

          {/* <div className="row">
            <div className="col-md-12 dashboard-container">
              <div className="d-flex justify-content-between align-items-center">
              </div>
              <br />
            </div>
          </div>         */}
      </div>
    );
  }
}

MydirectsComponent.propTypes = {
  getAllDirects: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    getAllDirects: state.myDirectsReducer.allDirects || [],
    users: state.profileReducer.users || [],
    allDirectsapproveall: state.myDirectsReducer.allDirectsapproveall || [],
  };
};

export default connect(mapStateToProps)(withRouter(MydirectsComponent));
