import * as actionTypes from "./mydirectsActionTypes";
const directListReducer = (state = { getMessage: false }, action) => {
  switch (action.type)
  {
    case actionTypes.FETCH_DIRECT_NAME:
      return Object.assign({}, state, {
        directList: action.payload
      });
    case actionTypes.FETCH_ALL_DIRECTS:
      return Object.assign({}, state, {
        allDirects: action.payload
      });
    case actionTypes.FETCH_ALL_DIRECTS_APPROVED_ALL:
      return Object.assign({}, state, {
        allDirectsapproveall: action.payload
      });
    default:
      return state;
  }
};
export default directListReducer;
