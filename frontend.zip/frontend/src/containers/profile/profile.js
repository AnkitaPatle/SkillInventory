import React, { Component } from "react";
import { connect } from "react-redux";
import { getAllUserInfo } from "./profileActions";
import logo from "./../../assets/images/login-bg.png";
import Routing from "../../routing";
import Header from "../../components/header/header";
import "./profile.css";
import { NavLink } from "react-router-dom";
import { API_URL } from './../../config';
import { Redirect } from "react-router-dom";
import logoimg from './../../assets/images/logo1.png';

class ProfileComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(getAllUserInfo());
  }

  render() {
    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }
    const { users } = this.props;
    if (users)
    {
    }
    return (
      <div className="login-form">
        <div className="form-title profile-title">
          <NavLink to='/dashboard'> <img src={logoimg} /></NavLink>
        </div>

        <div id="formContent" className="login-form-content position-relative">
          <div className="edit-profile-img">
             {this.props.users.profilePic ? <img
              src={API_URL + "/" + this.props.users.profilePic}
              className="img-fluid rounded-circle"
            /> : <img
                src={require("../../assets/images/profile.jpg")}
                className="img-fluid rounded-circle"
              />} 
          </div>
          <div className="profile-info-row">
            <p className="profile-info-row-heading">
              {users.firstname} {users.lastname}
            </p>
            <p className="profile-info-row-department break-word">{users.companyName}</p>
          </div>
          <div className="profile-info-row">
            <p className="profile-info-row-role break-word">{users.designation}</p>
            <p className="profile-info-row-location break-word">{users.location}</p>
          </div>
          <div className="profile-action">
            <NavLink className="btn edit-btn" to="/editProfile">
              Edit
            </NavLink>
            <NavLink className="btn continue-btn" to="/dashboard">
              Dashboard
            </NavLink>
          </div>
          <div>
            <img src={logo} alt="Logo" />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  let users = {};
  if (state.profileReducer.users !== undefined)
  {
    users = state.profileReducer;
    return users;
  } else
  {
    return { users };
  }
};

export default connect(mapStateToProps)(ProfileComponent);
