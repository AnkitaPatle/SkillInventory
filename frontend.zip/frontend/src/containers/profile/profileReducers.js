import * as actionTypes from "./profileActionTypes";
const profileReducer = (state = {}, action) => {
  switch (action.type) {
    case actionTypes.UPDATE_PROFILE_SUCCESS:
      return Object.assign({}, state, {
        users: action.payload
      });
    case actionTypes.GET_PROFILE_URL:
      return Object.assign({}, state, {
        usersData: action.payload
      });
    case actionTypes.FETCH_USER_SUCCESS:
      return Object.assign({}, state, {
        users: action.payload
      });
    default:
      return state;
  }
};
export default profileReducer;
