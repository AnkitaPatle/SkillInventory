import React, { Component } from "react";
import { connect } from "react-redux";
import Autosuggest from "react-autosuggest";
import * as actions from "./skillActions";
import "./skill.css";

const minOffset = 0;
const maxOffset = 20;
const thisYear = new Date().getFullYear();
let suggestedskills = [];

const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : suggestedskills.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;

class AddskillsComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      skillName: "",
      expertiseLevel: "",
      currentStatus: "",
      thisYear: thisYear,
      selectedYear: thisYear,
      message: "",
      value: "",
      suggestions: []
    };
  }

  submitAllSkillInfo(e) {
    const employeeSkill = {
      skillName: this.state.value,
      expertiseLevel: this.state.expertiseLevel,
      currentStatus: this.state.currentStatus,
      year: this.state.selectedYear
    };

    const { dispatch } = this.props;
    dispatch(actions.createSkills(employeeSkill));
    this.clearAllFields();
  }

  clearAllFields = () => {
    this.setState({ skillName: "" });
    this.setState({ expertiseLevel: "" });
    this.setState({ currentStatus: "" });
    this.setState({ selectedYear: thisYear });
  };

  onChangeSkillName(e) {
    this.setState({ skillName: e.target.value });
    this.setState({ message: "" });
    const { dispatch } = this.props;
    const skillname = { skillname: e.target.value };
    dispatch(actions.ChangeStatus());
  }
  onChangeExpertiseLevel(e) {
    this.setState({ expertiseLevel: e.target.value });
    this.setState({ message: "" });
  }
  onChangeCurrentStatus(e) {
    this.setState({ currentStatus: e.target.value });
    this.setState({ message: "" });
  }
  onChangeSelectedYear(e) {
    this.setState({ selectedYear: e.target.value });
    this.setState({ message: "" });
  }

  onChange = (event, { newValue }) => {
    this.setState({ value: newValue });
    const { dispatch } = this.props;
    const skillname = { skillname: event.target.value };
    dispatch(actions.getAllSkillsFromCluster(skillname));
  };

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: getSuggestions(value)
    });
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };

  render() {
    suggestedskills = this.props.allskills;
    const { skills } = this.props;
    const { thisYear, selectedYear } = this.state;
    const options = [];
    for (let i = minOffset; i <= maxOffset; i++)
    {
      const year = thisYear - i;
      options.push(<option value={year}>{year}</option>);
    }

    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: "Search by Skill (ex. Graphic Design)",
      value,
      onChange: this.onChange
    };
    return (
      <div>
        <div className="col-md-12">
          <div className="row">
            <div className="col-md-10">
              <div className="sectiontitle">
                <h2> Add Skill </h2>
              </div>

              <div className="col-md-12">
                <div className="row">
                  <div className="col-md-12">
                    <div className="form-group col-md-4">
                      <div className="colorcombo">
                        {this.props.getMessage ? this.props.roleStatus : ""}
                      </div>
                      <h4 className="labeltext"> Skill Name </h4>
                      <Autosuggest
                        suggestions={suggestions}
                        onSuggestionsFetchRequested={
                          this.onSuggestionsFetchRequested
                        }
                        onSuggestionsClearRequested={
                          this.onSuggestionsClearRequested
                        }
                        getSuggestionValue={getSuggestionValue}
                        renderSuggestion={renderSuggestion}
                        inputProps={inputProps}
                        value={this.state.value}
                        onChange={this.onChangeSkillName.bind(this)}
                      />
                    </div>
                  </div>

                  <div className="col-md-6 col-sm-6 col-xs-12">
                    <div className="form-group">
                      <label className="labeltext"> Expertise </label>
                      <br />

                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="expertiseLevel"
                          value="Expert"
                          onChange={this.onChangeExpertiseLevel.bind(this)}
                        />
                        <span class="checkround" />
                        Expert
                      </label>

                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="expertiseLevel"
                          value="Practitioner"
                          onChange={this.onChangeExpertiseLevel.bind(this)}
                        />
                        <span class="checkround" />
                        Practitioner
                      </label>
                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="expertiseLevel"
                          value="Novice"
                          onChange={this.onChangeExpertiseLevel.bind(this)}
                        />
                        <span class="checkround" />
                        Novice
                      </label>
                    </div>
                  </div>

                  <div className="col-md-6 col-sm-6 col-xs-12" />
                  <div className="col-md-6 col-sm-6 col-xs-12">
                    <div className="form-group">
                      <label className="labeltext">Status of Skillset</label>
                      <br />
                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="currentStatus"
                          value="Practicing"
                          onChange={this.onChangeCurrentStatus.bind(this)}
                        />
                        <span class="checkround" />
                        Practicing
                      </label>
                      <label className="radio-inline mr-2 radio">
                        <input
                          type="radio"
                          name="currentStatus"
                          value="Not Practicing"
                          onChange={this.onChangeCurrentStatus.bind(this)}
                        />
                        <span class="checkround" />
                        Not Practicing
                      </label>
                    </div>
                  </div>
                  <div className="col-md-6 col-sm-6 col-xs-12">
                    <div>
                      <h4> Last Practice </h4>
                      <select
                        defaultValue={this.state.selectedYear}
                        onChange={this.onChangeSelectedYear.bind(this)}
                        className="form-control col-md-2"
                      >
                        {options}
                      </select>
                    </div>
                  </div>
                </div>
                <button
                  onClick={this.submitAllSkillInfo.bind(this)}
                  className="btn btn-outline-primary btnadd"
                >
                  Add Skill Info
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    roleStatus: state.skillReducer.skills || "",
    getMessage: state.skillReducer.getMessage,
    allskills: state.skillReducer.allskills || []
  };
};

export default connect(mapStateToProps)(AddskillsComponent);
