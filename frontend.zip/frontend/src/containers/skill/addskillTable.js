import React, { Component } from "react";
import { connect } from "react-redux";
import Autosuggest from "react-autosuggest";
import { toastr } from "react-redux-toastr";
import SuggestSkill from "./suggestSkill";
import * as actions from "./skillActions";
import "./skill.css";
import StarRating from "./../../components/starRating/starRatingNew";
import { log } from "handlebars";
import ReactHover from 'react-hover';
import ReactTooltip from 'react-tooltip'

const currentYear = new Date().getFullYear();
const minYears = 0;
const maxYears = 20;

let suggestedskills = [];
const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
  ? []
  : suggestedskills.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};
const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;
// const optionsCursorTrueWithMargin = {
//   followCursor: true,
//   shiftX: 20,
//   shiftY: 0
// }

let experiencedList = [{ years: "0 to 0.5 Yrs" }, { years: "0.5 to 1 Yrs" }, { years: "1 to 3 Yrs" }, { years: "3 to 5 Yrs" }, { years: "5 to 10 Yrs" }, { years: "10 to 15 Yrs" }, { years: "15 to 20 Yrs" }, { years: "20 And Above" }];
let skillMessage = "";
class AddSkillTableComponent extends React.Component {
  constructor() {
    super();
    this.state = {
      skillname: "",
      // skills: [{ skilllevel: "", hovermessage: "", skillnmae: "" }],
      items: [],
      currentYear: currentYear,
      selectedYear: currentYear,
      value: "",
      suggestions: [],
      addnewSkillList: [],
      srchval: "",
      ischecked: false,
      // skilllevel: "Average",
      // hovermessage: "currently learning",
      allChecked : false,
      myProps : null
    };
  }

  handleFormSubmit = e => {
    this.setState({myProps : this.props}, ()=>{
    })
    e.preventDefault();
    if (this.state.value.toLocaleLowerCase() !== "" && this.state.value.toLocaleLowerCase().trim())
    {
      let items = [...this.state.items];
      if (this.state.value.trim())
      {
        if (!items.some(item => item.skillname === this.state.value.toLocaleLowerCase().trim()))
        {
          const { dispatch } = this.props;
          dispatch(actions.validateSkillsFromCluster(this.state.value.toLocaleLowerCase().trim())).then(res => {
            if (skillMessage === "")
            {
              items.push({
                check: false,
                currentStatus: "Not Practising",
                level: "Novice",
                skillname:this.state.value.toLocaleLowerCase().trim(),
                year: new Date().getFullYear(),
                experience: "0 to 0.5 Yrs",
                comment: "-",
                createdDate: new Date(),
              });
              this.setState({
                items,
                skillname: ""
              });
              this.setState({ value: "" })
            }
            else
            {
              toastr.warning("Warning!", skillMessage,  {
              showCloseButton: false,
              timeOut: 3000
              });
            }
          });
        } else
        {
          toastr.warning("Warning!", "This skill is already exists!", {
            showCloseButton: false,
            timeOut: 3000,
          });
        }
      }
    } else
    {
      toastr.warning("Warning!", "Please enter Skill Name and Press (+) to Queue!", {
        showCloseButton: false,
        timeOut: 3000,
      });
    }
  };
  handleInputChange = e => {
    let input = e.target;
    let name = e.target.name;
    let value = input.value;
    this.setState({
      [name]: value
    });
  };
  onChange = (event, { newValue }) => {
    let input = event.target;
    let name = event.target.name;
    let skillvalue = input.value;
    this.setState({
      [name]: skillvalue,
      srchval: event.target.innerText,
      value: newValue,
      skillname: newValue
    });
    const { dispatch } = this.props;
    const skillname = { skillname: newValue };
    dispatch(actions.getAllSkillsFromCluster(skillname));
  };
  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: getSuggestions(value)
    });
  };
  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };
  handleStateChange = id => {
    let count = 0;
    this.state.items[id].check = !this.state.items[id].check;
    document.getElementById("allchkbox").checked = false;
    if (this.state.items[id].check === false)
    {
      this.setState({ ischecked: false });
    }
      this.state.items.map((chk)=>{
      if(chk.check === true)
      {
        count = count + 1;
      }
    })
    if(this.state.items.length === count)
    {
      document.getElementById("allchkbox").checked = true;
    }

    const data = Object.assign([], this.state.items);
    this.setState({ items: data });
  };
  handleRatingChange = (id, rating) => {
    this.state.items[id].level = rating;
  };
  
  handleRadioButton = (index, change, skillvalue) => {
    if (document.getElementById('rd-btn-' + skillvalue).checked)
    {
      this.state.items[index].currentStatus = change;
      document.getElementById("year" + skillvalue).disabled = true;
      document.getElementById("year" + skillvalue).value = this.state.currentYear;
      this.state.items[index].year = this.state.currentYear;
    }
    else
    {
      this.state.items[index].currentStatus = "Not Practising";
      document.getElementById("year" + skillvalue).disabled = "";
    }
  };
  handleRadioButtonmob = (index, change, skillvalue) => {
    if (document.getElementById('rd-btn-mob' + skillvalue).checked)
    {
      this.state.items[index].currentStatus = change;
      document.getElementById("yearmob" + skillvalue).disabled = true;
      document.getElementById("yearmob" + skillvalue).value = this.state.currentYear;
      this.state.items[index].year = this.state.currentYear;
    }
    else
    {
      this.state.items[index].currentStatus = "Not Practising";
      document.getElementById("yearmob" + skillvalue).disabled = "";
    }
  };
  selectChangesDate = (e, index) => {
    this.state.items[index].year = parseInt(e.target.value);
  };
  selectChangesExperienced = (e, index) => {
    this.state.items[index].experience = e.target.value;
  }
  cleartable = () => {
    this.setState({ items: [] });
  };
    uncheckedSkills = skills => {
    this.setState({ items: skills });
    const x = document.getElementsByClassName("checkbox");
      for (let i = 0; i < x.length; i++) {
        x[i].checked = false;
      }
      const lastused = document.getElementsByClassName("lastused");
      for (let j = 0; j < lastused.length; j++) {
        lastused[j].disabled = false;
      }

      const Practicingchecked = document.getElementsByClassName("practschecked");
      for (let k = 0; k < Practicingchecked.length; k++) {
        Practicingchecked[k].checked = false;
      }

      const experience = document.getElementsByClassName("experience");
      for (let l = 0; l < experience.length; l++) {
        experience[l].value = '0 to 0.5 Yrs';
      }

      const starrating = document.getElementsByClassName("starrating");
      for (let m = 0; m < starrating.length; m++) {
        starrating[m].value = '0 to 0.5 Yrs';
      }

      const lastusedmob = document.getElementsByClassName("lastusedmob");
      for (let j = 0; j < lastusedmob.length; j++) {
        lastusedmob[j].disabled = false;
      }

      const practscheckedmob = document.getElementsByClassName("practscheckedmob");
      for (let k = 0; k < practscheckedmob.length; k++) {
        practscheckedmob[k].checked = false;
      }

      const experiencemob = document.getElementsByClassName("experiencemob");
      for (let l = 0; l < experiencemob.length; l++) {
        experiencemob[l].value = '0 to 0.5 Yrs';
      }  
  };
  onEnterKeyPress = e => {
    if (e.key === "Enter")
    {
      this.handleFormSubmit(e);
    }
  };

  render() {
    if (this.props.getValidateSkill.data !== undefined)
    {
      skillMessage = this.props.getValidateSkill.data;
    }
    suggestedskills = this.props.allskills;
    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: "Enter the Skill and Press (+) to Queue!",
      value,
      onChange: this.onChange,
      onKeyPress: this.onEnterKeyPress
    };
    return (
      <div className="App">
        <div className="row">
          <div className="add-skill-autosuggest-container input-group col-xl-3 col-lg-4 col-md-6 col-sm-6">
            <Autosuggest
              suggestions={suggestions}
              onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
              onSuggestionsClearRequested={this.onSuggestionsClearRequested}
              getSuggestionValue={getSuggestionValue}
              renderSuggestion={renderSuggestion}
              inputProps={inputProps}
              name="skillname"
              value={this.state.value}
              className="col-md-4 form-control"
            />
            <button className="btn btn-add" onClick={this.handleFormSubmit}>
              <i className="fa fa-plus btn-add-icon" aria-hidden="true"></i>
            </button>
          </div>
        </div>
        <div className="dashboard-para-search-text"></div>
        <Table
          items={this.state.items}
          handleParentStateChange={this.handleStateChange.bind(this)}
          ratingCheck={this.handleRatingChange.bind(this)}
          handleRadioButtonChange={this.handleRadioButton.bind(this)}
          handleRadioButtonChangemob = {this.handleRadioButtonmob.bind(this)}
          handleSelectChange={this.selectChangesDate.bind(this)}
          handleSelectExperiencedChange={this.selectChangesExperienced.bind(this)}
          checked={this.state.ischecked}
          skilllevel={this.state.skilllevel}
          hovermessage={this.state.hovermessage}
          starthover={this.state.handleRatingChange}
          myProps = {this.state.myProps}
          
        />
        <SuggestSkill
          skilldata={this.state.items}
          cleartable={this.cleartable}
          uncheckedSkills={this.uncheckedSkills}
          allChecked = {this.state.allChecked}
        ></SuggestSkill>
      </div>
    );
  }
}
class Table extends React.Component {
   constructor(props) {
   super(props);
      this.state = {
        allChecked : false
      }
   }
  allchecked(e, data) {
    this.setState({allChecked : !this.state.allChecked},()=>{
      sessionStorage.setItem("allChecked" , this.state.allChecked);
    })
    const {dispatch} = this.props.myProps;
    dispatch(actions.getAllChecked(!this.state.allChecked));
    data.map((data, key) => {
      if (e.target.checked)
      {
        if(document.getElementById("checkbox" + key).checked !== null)
        {
          document.getElementById("checkbox" + key).checked = true;
          data.check = true;
          this.setState({ allRowChecked: true });
        }
       
      } else
      {
        if(document.getElementById("checkbox" + key).checked !== null)
        {
        document.getElementById("checkbox" + key).checked = false;
        data.check = false;
        this.setState({ allRowChecked: false });
      }
    }
    });
  }

  state = {
    allRowChecked: false,
    items: [],
  };

  starthover = () => {
  }

  render() {
    const yearOptions = [];
    for (let i = minYears; i <= maxYears; i++)
    {
      const year = currentYear - i;
      yearOptions.push(<option value={year}>{year}</option>);
    }
    return (
      <div id="Table">
        <table className="table hideMob">
          {
            this.props.items.length !== 0 ? (
              <thead>
                <tr>
                  <th width="5%">
                    <div className="custom-control custom-checkbox custom-checkbox-field">
                      <input
                        type="checkbox"
                        className="form-control custom-control-input"
                        onChange={e => this.allchecked(e, this.props.items)}
                        defaultChecked={this.props.ischecked}
                        id="allchkbox"
                      />
                      <label className="custom-control-label" htmlFor="allchkbox"></label>
                    </div>
                  </th>
                  <th width="28%" className="th-skillName-1">SKILLSET</th>
                  <th width="20%">EXPERTISE LEVEL</th>
                  <th width="15%">EXPERIENCE</th>
                  <th width="20%">PRACTICING</th>
                  <th width="10%">LAST USED</th>

                </tr>
              </thead>
            ) : null}
          <tbody>
            {this.props.items.map((item, index) => {
              if (item.skillname.length > 0)
              {
                return (
                  <tr
                  id={"alchk"+index}
                    key={index}
                    className={
                       item.check
                        ? "rowSelected"
                        : ""
                    }
                  >
                    <td>
                      <div className="custom-control custom-checkbox custom-checkbox-field">
                        <input
                          type="checkbox"
                          name={"checkbox" + index}
                          className="form-control custom-control-input"
                          key={item._id}
                          id={"checkbox" + index}
                          onChange={this.props.handleParentStateChange.bind(
                            this,
                            index
                          )}
                          checked={item.check}
                        />
                        <label className="custom-control-label" htmlFor={"checkbox" + index}></label>
                      </div>
                    </td>
                    <td>{item.skillname}</td>
                    <td className="tdspace starrating">    
                        <StarRating 
                              name={item.skillname}
                              handleRatingChangeProp={this.props.ratingCheck.bind(
                                this,
                                index
                              )}
                            ></StarRating> 
                    </td>
                    <td>
                      <select
                        id={"experienced" + item.skillname.replace(/ /g, "") + "0"}
                        className="form-control experience"
                        data-title="experienced"
                        name="experiencedList"
                        onChange={e => this.props.handleSelectExperiencedChange(e, index)}
                      >
                        {experiencedList.map((item, key) => (
                          <option value={item.years}>{item.years}</option>
                        ))}
                      </select>
                    </td>
                    <td>
                      <div className="form-check-inline">
                        <div >
                        <div className ="custom-control custom-checkbox custom-checkbox-field">
                        <input className="form-control custom-control-input practschecked"
                          type="checkbox"
                          id={
                            "rd-btn-" + item.skillname.replace(/ /g, "") + "0"
                          }
                          name={"rd-btn-" + item.skillname.replace(/ /g, "")}
                          value="Practising"
                          onChange={this.props.handleRadioButtonChange.bind(
                            this,
                            index,
                            "Practising",
                            item.skillname.replace(/ /g, "") + "0"
                          )}
                        />  
                            <label className="custom-control-label" htmlFor={"chkbox0" + index}></label>
                            </div>
                        </div>
                      </div>
                      <div className="form-check-inline">
                      </div>
                    </td>
                    <td>
                      <select
                        id={"year" + item.skillname.replace(/ /g, "") + "0"}
                        className="form-control lastused"
                        data-title="year"
                        name="yearList"
                        onChange={e => this.props.handleSelectChange(e, index)}
                      >
                        {yearOptions}
                      </select>
                    </td>
                  </tr>
                );
              }
            })}
          </tbody>
        </table>
        <div className="add-skill-table-mobile showMob flex-column">
          {this.props.items.map((item, index) => {
            if (item.skillname.length > 0)
            {
              return (
                <div
                  key={index}
                  className="add-skill-table-row"
                >
                  <div className="add-skill-table-row-skillname">
                    <div className="custom-control custom-checkbox custom-checkbox-field" style={{ flex: "0 0 50px" }}>
                      <input
                        type="checkbox"
                        name={"checkbox" + index}
                        className="form-control custom-control-input"
                        key={item._id}
                        id={"checkbox" + index}
                        onChange={this.props.handleParentStateChange.bind(
                          this,
                          index
                        )}
                        checked={item.check}
                      />
                      <label className="custom-control-label" htmlFor={"checkbox" + index}>&nbsp;</label>
                    </div>
                    <label style={{ flex: "1", "fontSize": "18px", "fontWeight": "700", "marginBottom": "0" }} htmlFor={"checkbox" + index}>{item.skillname}</label>
                  </div>
                  <div className="add-skill-table-row-info">
                    <div style={{ flex: "0 0 50%" }}>
                      <label className="label-title">Expertise Level</label>
                          <StarRating
                              name={item.skillname}
                              handleRatingChangeProp={this.props.ratingCheck.bind(
                                this,
                                index
                              )}
                          ></StarRating>
                    </div>

                    <div>
                    <label className="label-title">Experience</label>
                      <select
                        id={"experienced" + item.skillname.replace(/ /g, "") + "0"}
                        className="form-control experiencemob"
                        data-title="experienced"
                        name="experiencedList"
                        onChange={e => this.props.handleSelectExperiencedChange(e, index)}
                      >
                        {experiencedList.map((item, key) => (
                          <option value={item.years}>{item.years}</option>
                        ))}

                      </select>
                    </div>
                    <div style={{ flex: "0 0 100%" }}>
                      <label className="label-title">Practicing</label>
                      <div >
                        <div className ="custom-control custom-checkbox custom-checkbox-field">
                        <input className="form-control custom-control-input practscheckedmob"
                          type="checkbox"
                          id={
                            "rd-btn-mob" + item.skillname.replace(/ /g, "") + "0"
                          }
                          name={"rd-btn-mob" + item.skillname.replace(/ /g, "")}
                          value="Practising"
                          onChange={this.props.handleRadioButtonChangemob.bind(
                            this,
                            index,
                            "Practising",
                            item.skillname.replace(/ /g, "") + "0"
                          )}
                        />  
                            <label className="custom-control-label" htmlFor={"chkboxm" + index}></label>
                            </div>
                        </div>
                    </div>
                    <div style={{ flex: "0 0 50%" }}>
                      <label className="label-title">LAST USED</label>
                      <select
                        id={"yearmob"+item.skillname.replace(/ /g, "") + "0"}
                        className="form-control lastusedmob"
                        data-title="yearmob"
                        name="yearList"
                        onChange={e => this.props.handleSelectChange(e, index)}
                      >
                        {yearOptions}
                      </select>
                    </div>
                  </div>
                </div>
              );
            }
          })}
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    allskills: state.skillReducer.allskills || [],
    getValidateSkill: state.skillReducer.getValidateSkill || [],
    getAllChecked: state.skillReducer.allChecked || null,
  };
};

export default connect(mapStateToProps)(AddSkillTableComponent);