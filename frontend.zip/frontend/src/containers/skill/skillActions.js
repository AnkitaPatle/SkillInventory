import axios from "axios";
import * as actionTypes from "./skillActionTypes";
import { API_URL } from './../../config';

export function getAllSkills() {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .get(API_URL + `/api/employee/listEmployeeSkills`, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_SKILL_SUCCESS,
          payload: res.data.data
        });
      });
  };
}

export function getAllSkillsFromCluster() {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .get(API_URL + `/api/listSkills`, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_ALL_SKILLS,
          payload: res.data.data
        });
      });
  };
}

export function getAllChecked(value){
  return function(dispatch){
    dispatch({
      type: actionTypes.ALL_CHECKED,
      payload : value
    })
  }
}


export function validateSkillsFromMaster(skillname,username) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/valMasterSkills`,{skillname:skillname , username:username},{ headers })
      .then(res => {
        dispatch({
          type: actionTypes.VALIDATE_ALL_MASTER_SKILLS,
          payload: res.data.err
        });
      });
  };
}

export function createSkills(employeeSkill) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(
        API_URL + `/api/addEmployeeSkill`,
        { employeeSkill },
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.CREATE_SKILL_SUCCESS,
          payload: { data: res.data.data, getMessage: true }
        });
        dispatch(getAllSkills());
      });
  };
}

export function ChangeStatus() {
  return function (dispatch) {
    dispatch({
      type: actionTypes.CHANGE_SKILL_STATUS,
      payload: { getMessage: false }
    });
  };
}

export function getSuggestedSkills() {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios.get(
      API_URL + `/api/employee/suggestSkill`,
      { headers }
    ).then(res => {
      dispatch({
        type: actionTypes.SUGGEST_SKILLS,
        payload: { data: res.data.data }
      });
    })
  }
}

export function updateskillAll(employeeAllSkill) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios.post(
      API_URL + `/api/employee/addAllSkill`,
      { employeeAllSkill },
      { headers }
    ).then(res => {
      dispatch({
        type: actionTypes.UPDATE_ALL_SKILLS,
        payload: { data: res.data.data }
      });
    })
  }
}

export function validateSkillsFromCluster(employeeSkill) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios.post(
      API_URL + `/api/employee/validateAllSkill`,
      { employeeSkill },
      { headers }
    ).then(res => {
      dispatch({
        type: actionTypes.VALIDATE_ALL_SKILLS,
        payload: { data: res.data.data }
      });
    })
  }
}