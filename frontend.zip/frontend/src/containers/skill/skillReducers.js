import * as actionTypes from "./skillActionTypes";
const skillReducer = (state = { getMessage: false }, action) => {
  switch (action.type) {
    case actionTypes.FETCH_SKILL_SUCCESS:
      return Object.assign({}, state, {
        employeeSkills: action.payload
      });
    case actionTypes.CREATE_SKILL_SUCCESS:
      return Object.assign({}, state, {
        skills: action.payload.data,
        getMessage: action.payload.getMessage
      });

    case actionTypes.FETCH_ALL_SKILLS:
      return Object.assign({}, state, {
        allskills: action.payload
      });

    case actionTypes.CHANGE_SKILL_STATUS: {
      return Object.assign({}, state, {
        getMessage: action.payload.getMessage
      });
    }

    case actionTypes.SUGGEST_SKILLS: {
      return Object.assign({}, state, {
        suggestedSkills: action.payload
      });
    }
    case actionTypes.UPDATE_ALL_SKILLS: {
      return Object.assign({}, state, {
        getMessage: action.payload
      });
    }
    case actionTypes.VALIDATE_ALL_SKILLS: {
      return Object.assign({}, state, {
        getValidateSkill: action.payload
      });
    }
    case actionTypes.VALIDATE_ALL_MASTER_SKILLS: {
      return Object.assign({}, state, {
        masterValidateSkill: action.payload
      });
    }
    
    case actionTypes.ALL_CHECKED : {
      return Object.assign({}, state, {
        allChecked : action.payload
      })
    }
    
    default:
      return state;
  }
};
export default skillReducer;
