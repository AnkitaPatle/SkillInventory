import React, { Component } from "react";
import { MDBInput, MDBDataTable } from "mdbreact";
import StarRating from "./../../components/starRating/starRating";
import { connect } from "react-redux";
import * as actions from "./skillActions";
import { toastr } from "react-redux-toastr";
import { NavLink, Redirect } from "react-router-dom";

class SuggestSkill extends Component {
  constructor(props) {
    super(props);
    this.state = {
      addSkillList: [],
      deafultYear: 2019,
      finalSkillList: [],
      uncheckedSkillList: [],
      ischecked: "",
      checkboxdta: [],
      message: "",
    
    };
  }

  handleRatingChange(id, rating) {
    const data = Object.assign([], this.state.addSkillList);
    data[id].level = rating;
    this.setState({ addSkillList: data });
  }

  handleSingleCheckboxChange(id) {
    const data = Object.assign([], this.state.addSkillList);
    data[id].check = !data[id].check;
    this.setState({ addSkillList: data });
  }

  handleRadioButtonChange(id, status) {
    const data = Object.assign([], this.state.addSkillList);
    data[id].currentStatus = status;
    this.setState({ addSkillList: data });
  }

  handleSelectChange(e, id) {
    const data = Object.assign([], this.state.addSkillList);
    data[id].year = e.target.value;
    this.setState({ addSkillList: data });
  }

  handleRowClick() {}

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.getSuggestedSkills());
  }

  addAllSkill = () => {
    this.setState({ finalSkillList: [] });
    this.state.addSkillList.map((skillsuggestdata, key) => {
      if (this.state.addSkillList[key].check) {
        let obj = new Object();
        obj = Object.assign({}, this.state.addSkillList[key]);
        delete obj["check"];
        this.state.finalSkillList.push(obj);
      }
    });

    this.props.skilldata.map((skilldata, key) => {
      if (this.props.skilldata[key].check) {
        let obj = new Object();
        obj = Object.assign({}, this.props.skilldata[key]);
        delete obj["check"];
        this.state.finalSkillList.push(obj);
      }
    });

    this.props.skilldata.map((skilldata, key) => {
      if (!this.props.skilldata[key].check) {
        let obj = new Object();
        obj = Object.assign({}, this.props.skilldata[key]);
        delete obj["check" == false];
        this.state.uncheckedSkillList.push(obj);
      }
    });

    const employeeAllSkill = this.state.finalSkillList;
    const { dispatch } = this.props;
    if (employeeAllSkill.length == 1) {
      dispatch(actions.updateskillAll(employeeAllSkill)).then(data => {
        toastr.success("Success", "Skill Added Successfully.", {
          showCloseButton: false,
          timeOut: 3000
        });
      });
      if (this.state.finalSkillList.length == this.props.skilldata.length) {
        this.props.cleartable();
      } else {
        this.props.uncheckedSkills(this.state.uncheckedSkillList);
        this.setState({ uncheckedSkillList: [] });
      }
      this.setState({ message: "" });
    } else {
       dispatch(actions.updateskillAll(employeeAllSkill)).then(data => {
        toastr.success("Success", "Skills Added Successfully.", {
          showCloseButton: false,
          timeOut: 3000
        });
      });
      if (this.state.finalSkillList.length == this.props.skilldata.length) {
        this.props.cleartable();
      } else {
        this.props.uncheckedSkills(this.state.uncheckedSkillList);
        this.setState({ uncheckedSkillList: [] });
      }
      this.setState({ message: "" });
      // this.setState({ message: "Please select skill to add!" });
      // toastr.warning("Warning!", "Please Select/Check skill to add in your Profile!", {
      //   showCloseButton: false
      // });
    }
  };

  allcheckedsuggest(e, data) {
    data.map((data, key) => {
      if (e.target.checked) {
        document.getElementById("chk" + key).checked = true;
        this.state.addSkillList[key].check = true;
      } else {
        document.getElementById("chk" + key).checked = false;
        this.state.addSkillList[key].check = false;
      }
    });
  }

  render() {
    let yearList = [];
    const yearStart = 0;
    const yearEnd = 20;

    if (this.props.suggestedSkills.data) {
      const data = this.props.suggestedSkills.data.map(skill => {
        const addSkillObject = {
          check: false,
          skillname: skill,
          level: "Novice",
          currentStatus: "Practising",
          year: new Date().getFullYear()
        };
        return addSkillObject;
      });
      if (!this.state.addSkillList.length) {
        this.setState({ addSkillList: data });
      }
    }

    for (let i = yearStart; i <= yearEnd; i++) {
      const temp = new Date().getFullYear() - i;
      yearList.push(
        <option value={temp} key={temp}>
          {temp}
        </option>
      );
    }
    const rowData = this.state.addSkillList.map((skillObj, index) => {
      return {
        cb: (
          <div className="custom-control custom-checkbox custom-checkbox-field">
            <input
              type="checkbox"
              id={"chk" + index}
              onChange={this.handleSingleCheckboxChange.bind(this, index)}
              checked={this.state.addSkillList[index].check}
            />
            <label className="custom-control-label" htmlFor={"chk" + index}>
              &nbsp;
            </label>
          </div>
        ),
        skillname: skillObj.skillname,
        level: (
          <StarRating
            name={skillObj.skillname}
            handleRatingChangeProp={this.handleRatingChange.bind(this, index)}
          ></StarRating>
        ),
        currentStatus: (
          <div>
            <div className="form-check-inline">
              <label class="form-check-label">
                <input
                  type="radio"
                  id={"rd-btn-" + skillObj.skillname.replace(/ /g, "") + "0"}
                  class="form-check-input"
                  name={"rd-btn-" + skillObj.skillname.replace(/ /g, "")}
                  value="Practising"
                  onChange={this.handleRadioButtonChange.bind(
                    this,
                    index,
                    "Practising"
                  )}
                />
                Practising
              </label>
            </div>
            <div className="form-check-inline">
              <label class="form-check-label">
                <input
                  type="radio"
                  id={"rd-btn-" + skillObj.skillname.replace(/ /g, "") + "1"}
                  class="form-check-input"
                  name={"rd-btn-" + skillObj.skillname.replace(/ /g, "")}
                  value="Not Practising"
                  onChange={this.handleRadioButtonChange.bind(
                    this,
                    index,
                    "Not Practising"
                  )}
                />
                Not Practising
              </label>
            </div>
          </div>
        ),
        year: (
          <div className="form-group">
            <select
              id={skillObj.skillname.replace(/ /g, "")}
              className="form-control"
              name="yearList"
              defaultValue={this.state.addSkillList[index].year}
              onChange={e => this.handleSelectChange(e, index)}
            >
              {yearList}
            </select>
          </div>
        ),
        clickEvent: this.handleRowClick.bind(this)
      };
    });

    const data = {
      columns: [
        {
          label: (
            <div className="custom-control custom-checkbox custom-checkbox-field">
              <input
                type="checkbox"
                class="form-control custom-control-input"
                id="multicheckbox"
                onChange={e =>
                  this.allcheckedsuggest(e, this.state.addSkillList)
                }
              />
              <label className="custom-control-label" htmlFor="multicheckbox">
                &nbsp;
              </label>
            </div>
          ),
          field: "cb"
        },
        {
          label: "SKILLSET",
          field: "skillname"
        },
        {
          label: "EXPERTISE LEVEL",
          field: "level"
        },
        {
          label: "STATUS OF SKILLSET",
          field: "currentStatus"
        },
        {
          label: "LAST USED",
          field: "year"
        }
      ],

      rows: rowData
    };

    let checked = true;
    if(this.props.allChecked){
      checked = true
    }else{
      this.props.skilldata && this.props.skilldata.map((rec, ind)=>{
      if(rec.check == true){
        checked = false;
      }
    })
    }
    
    return (
      <div className="suggest-skill-table">
        <button
          className="btnAddSkills addnewskill custom-btn" type="button"
          onClick={this.addAllSkill}
          disabled = {this.props.allChecked ? true : checked}
        >
          <NavLink className="hideMob" to="/skill">
            Add Skills
          </NavLink>
          <div className="showMob fa fa-plus"></div>
        </button>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    suggestedSkills: state.skillReducer.suggestedSkills || [],
    getMessage: state.skillReducer.getMessage.data,
    getAllChecked: state.skillReducer.allChecked || null,
  };
};

export default connect(mapStateToProps)(SuggestSkill);
