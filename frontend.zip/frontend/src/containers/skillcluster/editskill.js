import React, { Component } from "react";
import Modal from 'react-bootstrap/Modal';
import { toastr } from "react-redux-toastr";

const customStyles = {
};

class EditSkillModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modalIsOpen: this.props.modalOpen ? true : false,
      skill: this.props.selectedData ? this.props.selectedData.name : ""
    };
  }

  onChangeSkill(e) {
    this.setState({ skill: e.target.value });
  }
  openModal() {
    this.setState({ modalIsOpen: true });
  }

  afterOpenModal() {
  }

  closeModal = e => {
    if (this.state.skill !== "" && this.state.skill.trim()){
    const skillName = {
      skillname: this.state.skill
    };
    this.props.updateMasterSkill(skillName);
    }else {
       toastr.warning("Warning!", "Please enter skill name!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  };

  render() {
    return (
      <Modal backdrop="static"
        show={this.state.modalIsOpen}
        onHide={this.props.closeEditSkillModal}
        contentlabel="Edit Skill Modal"
        centered
        className="update-skill-modal"
      >
        <Modal.Header closeButton>
          <Modal.Title>Update Skill</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div class="form-group row">
            <label htmlFor="skill" class="col-form-label">Skill Name</label>
            <div class="col">
              <input type="text" class="form-control"
                name="skill"
                id="skill"
                onChange={this.onChangeSkill.bind(this)}
                value={this.state.skill}
                maxLength={50}
              />
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button
            onClick={this.props.closeEditSkillModal}
            className="edit-skill-action-cancel"
          >
            {" "}
            Cancel{" "}
          </button>

          <button
            type="submit"
            className="edit-skill-action-save"
            onClick={this.closeModal}
          >
            Update
          </button>
        </Modal.Footer>
      </Modal>
    );
  }
}

export default EditSkillModal;
