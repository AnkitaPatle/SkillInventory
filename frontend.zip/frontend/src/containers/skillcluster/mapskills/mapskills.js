import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import Autosuggest from "react-autosuggest";
import Routing from "../../../routing";
import Header from "../../../components/header/header";
import * as actions from "./mapskillsActions";
import * as skillactions from "./../../skill/skillActions";
import { Redirect } from "react-router-dom";
import "./mapskills.css";

let childskills = [];

const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : childskills.filter(
        lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
      );
};

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;
class MapskillsComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      skillName: "",
      parentSkill: "",
      mappedskill: [],

      value: "",
      suggestions: [],
      parentvalue: "",
      parentsuggentions: []
    };
  }
  onChangeSkill(e) {
    this.setState({ skillName: e.target.value });
  }
  onChangeParent(e) {
    this.setState({ parentSkill: e.target.value });
  }

  MapSkills() {
    const mapskill = {
      skillName: this.state.value,
      parentSkill: this.state.parentSkill
    };

    const { dispatch } = this.props;
    dispatch(actions.MapSkills(mapskill));
  }

  onChange = (event, { newValue }) => {
    this.setState({ value: newValue });
    const { dispatch } = this.props;
    const skillname = { skillname: event.target.value };
    dispatch(skillactions.getAllSkillsFromCluster(skillname));
  };

  onChangeForParent = (event, { newValue }) => {
    this.setState({
      parentvalue: newValue
    });
    const { dispatch } = this.props;
    const parentSkill = { parentSkill: event.target.value };
    dispatch(skillactions.getAllSkillsFromCluster(parentSkill));
  };

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: getSuggestions(value)
    });
  };

  onSuggestionsClearRequested = () => {
    this.setState({ suggestions: [] });
  };

  render() {

    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }

    childskills = this.props.allskills;
    const { value, suggestions, parentvalue } = this.state;
    const inputProps = {
      placeholder: "select child skill to map",
      value,
      onChange: this.onChange,
      className: "col-md-4"
    };
    const inputPropsforparent = {
      placeholder: "select parent skill to map",
      value: parentvalue,
      onChange: this.onChangeForParent,
      className: "col-md-4"
    };
    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <div className="sectiontitle">
                <h2>Add skill to cluster</h2>
              </div>

              <div className="form-group ">
                <label htmlFor="skill" className="col-md-1">
                  Select Skills{" "}
                </label>

                <Autosuggest
                  suggestions={suggestions}
                  onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                  onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                  getSuggestionValue={getSuggestionValue}
                  renderSuggestion={renderSuggestion}
                  inputProps={inputProps}
                  value={this.state.value}
                  onChange={this.onChangeSkill.bind(this)}
                />
              </div>
              <div className="form-group">
                <label htmlFor="parent" className="col-md-1">
                  Select Parent
                </label>
                <Autosuggest
                  suggestions={suggestions}
                  onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
                  onSuggestionsClearRequested={this.onSuggestionsClearRequested}
                  getSuggestionValue={getSuggestionValue}
                  renderSuggestion={renderSuggestion}
                  inputProps={inputPropsforparent}
                  value={this.state.parentSkill}
                  onChange={this.onChangeParent.bind(this)}
                />
              </div>
              <div className="form-group">
                <label htmlFor="parent" className="col-md-2" />
                <button
                  type="submit"
                  className="btn btn-success"
                  onClick={this.MapSkills.bind(this)}
                >
                  Add to cluster
                </button>
              </div>

              <div className="col-md-12">
                <table className="table table-borderd table-striped">
                  <thead>
                    <tr>
                      <th>Skill Name</th>
                      <th>Parent Name</th>
                      <th>Added By</th>
                      <th>Remove Skill</th>
                    </tr>
                  </thead>

                  <tbody>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

class TableRow extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <tr>
        {Object.keys(this.props.rec[0]).map((r, i) =>
          r !== "_id" ? (
            r !== "__v" ? (
              r !== "parentId" ? (
                r !== "createdDate" ? (
                  <td>{this.props.row[r]}</td>
                ) : null
              ) : null
            ) : null
          ) : null
        )}
      </tr>
    );
  }
}

const mapStateToProps = state => {
  return {
    allskills: state.skillReducer.allskills || []
  };
};
export default connect(mapStateToProps)(MapskillsComponent);
