import React, { Component } from "react";
import { connect } from "react-redux";
import DataTable from "react-data-table-component";
import EditSkillModal from "./editskill";
import Header from "../../components/header/header";
import Routing from "../../routing";
import * as actions from "./skillclusterActions";
import { toastr } from "react-redux-toastr";
import * as skillsactions from "./../skill/skillActions";
import Autosuggest from "react-autosuggest";
import { Redirect } from "react-router-dom";
import "./skillcluster.css";

let suggestedskills = [];
const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : suggestedskills.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;

class SkillClusterComponent extends Component {
  state = {
    skill: "",
    isModalOpen: false,
    selectedRow: [],
    oldSkillName: "",
    value: "",
    suggestions: [],
    skillName: ""
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.GetSkillList());
  }

  onChangeSkill(e) {
    this.setState({ skill: e.target.innerText });
    const { dispatch } = this.props;
    dispatch(actions.ChangeStatus());
  }

  AddSkillToCluster(e) {
    if (this.state.value !== "" && this.state.value.trim())
    {
      if (e.target.name === "skill")
      {
      }
      const skillCluster = {
        skill:this.state.skill.charAt(0).toUpperCase()+""+this.state.skill.slice(1)
      };
      const { dispatch } = this.props;
      dispatch(actions.AddSkillToCluster(skillCluster)).then(data => {
          this.setState({ value: "" });
          if(this.props.getMessage === skillCluster.skill+" added successfully in Skill Master")
          {
            toastr.success("Success", "''"+this.props.getMessage.split(" ")[0]+"''  "+this.props.getMessage.split(" ")[1]+" "+this.props.getMessage.split(" ")[2]+" "+this.props.getMessage.split(" ")[3]+" "+this.props.getMessage.split(" ")[4]+" "+this.props.getMessage.split(" ")[5], {
              showCloseButton: false,
              timeOut: 3000
            });
          }
          else{
            toastr.warning("Warning!", this.props.getMessage, {
              showCloseButton: false,
              timeOut: 3000
            });
          }
      });
    } else
    {
      toastr.warning("Warning!", "Please enter Skill Name and Press (+) to Queue!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  }

  removeSkill() {
    const { dispatch } = this.props.row.skillName;
    dispatch(actions.RemoveSkill());
  }

  getMessageClasses() {
    let classes = "col-md-4 ";
    classes +=
      this.props.showMessage === true
        ? "successmesage"
        : this.props.messageClass;
    return classes;
  }

  updateSkill = e => {
    const editskill = {
       newSkill: e.skillname.charAt(0).toUpperCase()+""+e.skillname.slice(1),
      oldSkill: this.state.oldSkillName
    };
    const { dispatch } = this.props;
    Promise.resolve(
      dispatch(actions.editMasterSkill(editskill))
        .then(res => dispatch(actions.GetSkillList()))
        .then(data => {
          toastr.success("Success", "Skill updated successfully.", {
            showCloseButton: false,
            timeOut: 3000
          });
        })
    );
    this.setState({ isModalOpen: false });
  };

  editMasterSkill = (item) => {
    this.setState({ isModalOpen: true, selectedRow: item, oldSkillName: item.name });
  }

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({ skill: value });
    this.setState({
      suggestions: getSuggestions(value)
    });
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };
  onChange = (event, { newValue }) => {
    this.setState({ skill: event.target.innerText });
    this.setState({ value: newValue });
    const { dispatch } = this.props;
    const skillname = { skillname: event.target.value };
    dispatch(skillsactions.getAllSkillsFromCluster(skillname));
  };

  closeEditSkillModal = () => {
    this.setState({ isModalOpen: false });
  }

  onEnterKeyPress = e => {
    if (e.key === "Enter")
    {
      this.AddSkillToCluster(e);
    }
  };

  render() {

    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }

    const { value, suggestions } = this.state;
    suggestedskills = this.props.allskills;
    const inputProps = {
      placeholder: "Enter the Skill and Press (+) to Queue!",
      value,
      onChange: this.onChange,
      onKeyPress: this.onEnterKeyPress
    };

    const collection = [];
    if (this.props.skilllist)
    {
      this.props.skilllist.forEach((item, index) => {
        collection.push({
          srno: index + 1,
          name: item.name.charAt(0).toUpperCase() + item.name.slice(1),
          action: (<span className="icon icon-edit action-icon" onClick={() => this.editMasterSkill(item)}></span>
          )
        });
      });
    }

    const data = {
      columns: [
        {
          name: "SR. NO.",
          selector: "srno",
          width: "95px",
        },
        {
          name: "SKILL NAME",
          selector: "name",
          style: {
            "word-break": "break-all",
            "width": "70%"
          },
        },
        {
          name: "ACTION",
          selector: "action",
          ignoreRowClick: true,
          allowOverflow: true,
          button: true,
        }
      ],
      rows: collection
    };
    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <h1 className="dashboard-page-title">Add Skills to Skill Master</h1>
              <div className="row">
                <div className="add-skill-autosuggest-container input-group col-xl-3 col-lg-4 col-md-6 col-sm-6">
                  <Autosuggest
                    suggestions={suggestions}
                    onSuggestionsFetchRequested={
                      this.onSuggestionsFetchRequested
                    }
                    onSuggestionsClearRequested={
                      this.onSuggestionsClearRequested
                    }
                    getSuggestionValue={getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                    inputProps={inputProps}
                    name="skillname"
                    value={this.state.value}
                    onChange={this.onChangeSkill.bind(this)}
                    className="col-md-4 form-control"
                  />
                  <button
                    className="btn btn-add"
                    onClick={this.AddSkillToCluster.bind(this)}
                  >
                    <i className="fa fa-plus btn-add-icon" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
              <div className="row mb-4">
                <div className="skill-searchbox input-group col-xl-3 col-lg-4 col-md-6 col-sm-6">
                </div>
              </div>

              <DataTable
                columns={data.columns}
                data={data.rows}
                noHeader
                pagination
                className="skill-clustor-datatable"
              />
              {this.state.isModalOpen ? (
                <EditSkillModal
                  closeEditSkillModal={this.closeEditSkillModal}
                  modalOpen={true}
                  updateMasterSkill={this.updateSkill}
                  selectedData={this.state.selectedRow}
                />
              ) : null}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    roleStatus: state.skillclusterReducer.skillinfo || "",
    getMessage: state.skillclusterReducer.getMessage.data,
    skilllist: state.skillclusterReducer.skilllist || [],
    deleteMessageStatus: state.skillclusterReducer.deleteskill,
    deleteMessage: state.skillclusterReducer.deleteMessage,
    statusMaster: state.skillclusterReducer.statusMaster || "",
    allskills: state.skillReducer.allskills || []
  };
};

export default connect(mapStateToProps)(SkillClusterComponent);
