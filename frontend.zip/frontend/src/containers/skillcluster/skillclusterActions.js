import axios from "axios";
import * as actionTypes from "./skillclusterActionTypes";
import { toastr } from "react-redux-toastr";
import { API_URL } from './../../config';

export function GetSkillList() {
  return function (dispatch) {
    var headers = {
      "content-type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .get(API_URL + "/api/listSkills", { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_SKILL_LIST,
          payload: res.data.data
        });
      });
  };
}

export function AddSkillToCluster(skillCluster) {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + "/api/addSkill",
        { skillCluster },
        { headers: headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.ADD_SKILL_TO_CLUSTER,
          payload: { data: res.data.data ? res.data.data : res.data.err, getMessage: true }
        });
        dispatch(GetSkillList());
      })
      .catch(err => {
        dispatch({
          payload: { getMessage: err.data.data }
        });
        dispatch(GetSkillList());
      });
  };
}

export function RemoveSkill(skillName) {
  return function (dispatch) {
    var headers = {
      "content-type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .delete(
        API_URL + "/api/removeskill",
        { skillName },
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.REMOVE_SKILL,
          payload: res.data.data
        });
      });
  };
}

export function ChangeStatus() {
  return function (dispatch) {
    dispatch({
      type: actionTypes.CHANGE_STATUS,
      payload: { showMessage: false, messageClass: "failuremessage" }
    });
  };
}

export function editMasterSkill(editSkill, oldSkillName) {
  return function (dispatch) {
    const headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .put(
        API_URL + "/api/editMasterSkill",
        { editSkill },
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.EDIT_MASTER_SKILL,
          payload: { data: res.data.data }
        });
      });
  };
}
