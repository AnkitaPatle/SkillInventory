import * as actionTypes from "./skillclusterActionTypes";

const skillclusterReducer = (state = { getMessage: false }, action) => {
  switch (action.type) {
    case actionTypes.ADD_SKILL_TO_CLUSTER:
      return Object.assign({}, state, {
        getMessage: action.payload
      });
    case actionTypes.FETCH_SKILL_LIST: {
      return Object.assign({}, state, {
        skilllist: action.payload
      });
    }
    case actionTypes.REMOVE_SKILL: {
      return Object.assign({}, state, {
        deleteskill: action.payload.data,
        deleteMessage: "Skill deleted from cluster."
      });
    }
    case actionTypes.CHANGE_STATUS: {
      return Object.assign({}, state, {
        showMessage: action.payload.showMessage
      });
    }
    case actionTypes.EDIT_MASTER_SKILL: {
      return Object.assign({}, state, {
        statusMaster: action.payload.data
      });
    }
    default:
      return state;
  }
};

export default skillclusterReducer;
