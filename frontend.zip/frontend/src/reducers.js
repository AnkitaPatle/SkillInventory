import { combineReducers } from "redux";
import skillReducer from "./containers/skill/skillReducers";
import loginReducer from "./containers/login/loginReducers";
import prfileReducer from "./containers/skill/skillReducers";
import profileReducer from "./containers/profile/profileReducers";
import assignRoleReducer from "./containers/admin/role/assignRoleReducers";
import skillclusterReducer from "./containers/skillcluster/skillclusterReducers";
import mapskillReducer from "./containers/skillcluster/mapskills/mapskillsReducers";
import changePasswordReducer from "./containers/admin/changepassword/changePasswordReducers";
import dashboardReducer from "./containers/dashboard/dashboardReducers";
import approveskillReducer from "./containers/manager/approveskillReducers";
import dashboardskillReducer from "./containers/dashboardskill/dashboardReducers";
import askExpertReducer from "./containers/askexpert/askExpertReducer";
import myDirectsReducer from "./containers/manager/mydirects/mydirectsReducers";
import { reducer as toastrReducer } from "react-redux-toastr";
import employeeProfileReducer from './containers/manager/mydirects/employeeProfile/employeeProfileReducers';

const rootReducer = combineReducers({
  loginReducer,
  skillReducer,
  prfileReducer,
  profileReducer,
  assignRoleReducer,
  skillclusterReducer,
  changePasswordReducer,
  mapskillReducer,
  dashboardReducer,
  approveskillReducer,
  dashboardskillReducer,
  askExpertReducer,
  myDirectsReducer,
  employeeProfileReducer,
  toastr: toastrReducer
});

export default rootReducer;
