import LoginComponent from "./containers/login/login";
import Dashboard from "./containers/dashboard/dashboard";

import ManagerComponent from "./containers/manager/manager";

import ApproveSkillComponent from "./containers/manager/approveskill";

import DirectsComponent from "./containers/directs/directs";
import SkillClusterComponent from "./containers/skillcluster/skillcluster";
import MapskillsComponent from "./containers/skillcluster/mapskills/mapskills";
import EmployeeComponent from "./containers/employee/employee";

import AssignroleComponent from "./containers/admin/role/assignrole";
import AccountdeactivationComponent from "./containers/admin/account/accountdeactivation";
import ChangepasswordComponent from "./containers/admin/changepassword/changepassword";

import ProfileComponent from "./containers/profile/profile";
import LogoutComponent from "./containers/logout/logout";

import SkillsComponent from "./containers/skill/skill";
import AddDirectSkillComponent from './containers/manager/adddirectskill/adddirectskill';
import Askexpert from './containers/askexpert/askexpert';
import PastqueryComponent from './containers/askexpert/pastqueries';
import EmployeeProfile from './containers/manager/mydirects/employeeProfile/employeeProfile';
import AskexpertNew from './containers/askexpert/askexpertNew';
import PastQueriesNew from './containers/askexpert/pastqueriesNew';

export default {
  Employee: [

    {
      isExact: true,
      path: "/dashboard",
      component: Dashboard,
      name: "Dashboard"
    },
    {
      isExact: true,
      path: "/skill",
      component: SkillsComponent,
      name: "Add Skill"
    },
    {
      isExact: true,
      path: "/profile",
      component: ProfileComponent,
      name: "Profile"
    },
    // {
    //   isExact: true,
    //   path: "/askexpert",
    //   component: Askexpert,
    //   name: "Askexpert"
    // },
    // {
    //   isExact: true,
    //   path: "/pastqueries",
    //   component: PastqueryComponent,
    //   name: "Past Queries"
    // },
    {
      isExact: true,
      path: "/askexpert",
      component: AskexpertNew,
      name: "Ask Expert New"
    },
    {
      isExact: true,
      path: "/pastqueries",
      component: PastQueriesNew,
      name: "Ask Expert New"
    },
    
    {
      isExact: true,
      path: "/logout",
      component: LogoutComponent,
      name: "Logout"
    }
  ],
  Capdev: [
    {
      isExact: true,
      path: "/dashboard",
      component: Dashboard,
      name: "Dashboard"
    },
    {
      isExact: true,
      path: "/employee",
      component: EmployeeComponent,
      name: "Employee List"
    },
    {
      isExact: true,
      path: "/skill",
      component: SkillsComponent,
      name: "Add Skill"
    },
    {
      isExact: true,
      path: "/cluster",
      component: SkillClusterComponent,
      name: "Skill Cluster"
    },
    {
      isExact: true,
      path: "/mapskills",
      component: MapskillsComponent,
      name: "Map Skills"
    },
    {
      isExact: true,
      path: "/profile",
      component: ProfileComponent,
      name: "Profile"
    },
    {
      isExact: true,
      path: "/logout",
      component: LogoutComponent,
      name: "Logout"
    }
  ],
  DM: [
    {
      isExact: true,
      path: "/dashboard",
      component: Dashboard,
      name: "Dashboard"
    },
    {
      isExact: true,
      path: "/skill",
      component: SkillsComponent,
      name: "Add Skill"
    },
    {
      isExact: true,
      path: "/approveskill",
      component: ApproveSkillComponent,
      name: "Approve Skill"
    },
    {
      isExact: true,
      path: "/profile",
      component: ProfileComponent,
      name: "Profile"
    },
    {
      isExact: true,
      path: "/empProfile",
      component: EmployeeProfile,
      name: "EmployeeProfile"
    },

    //    {
    //   isExact: true,
    //   path: "/dirctskil",
    //   component: AddDirectSkillComponent,
    //   name: "Add Direct Skill"
    // },
    {
      isExact: true,
      path: "/logout",
      component: LogoutComponent,
      name: "Logout"
    }

  ],
  Admin: [
    {
      isExact: true,
      path: "/dashboard",
      component: Dashboard,
      name: "Dashboard"
    },
    {
      isExact: true,
      path: "/assignrole",
      component: AssignroleComponent,
      name: "Assign Role"
    },
    {
      isExact: true,
      path: "/changepassword",
      component: ChangepasswordComponent,
      name: "Change Password"
    },
    {
      isExact: true,
      path: "/logout",
      component: LogoutComponent,
      name: "Logout"
    }
  ]
};


